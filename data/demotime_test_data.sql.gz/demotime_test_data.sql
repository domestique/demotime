--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.3
-- Dumped by pg_dump version 9.5.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: demotime_attachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_attachment (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    attachment character varying(100) NOT NULL,
    object_id integer NOT NULL,
    content_type_id integer NOT NULL,
    attachment_type character varying(128) NOT NULL,
    description character varying(2048),
    sort_order integer NOT NULL,
    CONSTRAINT demotime_attachment_object_id_check CHECK ((object_id >= 0))
);


ALTER TABLE demotime_attachment OWNER TO postgres;

--
-- Name: demotime_attachment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_attachment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_attachment_id_seq OWNER TO postgres;

--
-- Name: demotime_attachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_attachment_id_seq OWNED BY demotime_attachment.id;


--
-- Name: demotime_comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_comment (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    comment text NOT NULL,
    commenter_id integer NOT NULL,
    thread_id integer NOT NULL
);


ALTER TABLE demotime_comment OWNER TO postgres;

--
-- Name: demotime_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_comment_id_seq OWNER TO postgres;

--
-- Name: demotime_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_comment_id_seq OWNED BY demotime_comment.id;


--
-- Name: demotime_commentthread; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_commentthread (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    review_revision_id integer NOT NULL
);


ALTER TABLE demotime_commentthread OWNER TO postgres;

--
-- Name: demotime_commentthread_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_commentthread_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_commentthread_id_seq OWNER TO postgres;

--
-- Name: demotime_commentthread_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_commentthread_id_seq OWNED BY demotime_commentthread.id;


--
-- Name: demotime_creator; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_creator (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    active boolean NOT NULL,
    review_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE demotime_creator OWNER TO postgres;

--
-- Name: demotime_creator_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_creator_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_creator_id_seq OWNER TO postgres;

--
-- Name: demotime_creator_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_creator_id_seq OWNED BY demotime_creator.id;


--
-- Name: demotime_event; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_event (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    object_id integer NOT NULL,
    related_type character varying(64) NOT NULL,
    content_type_id integer NOT NULL,
    project_id integer NOT NULL,
    event_type_id integer NOT NULL,
    user_id integer NOT NULL,
    review_id integer NOT NULL,
    CONSTRAINT demotime_event_object_id_check CHECK ((object_id >= 0))
);


ALTER TABLE demotime_event OWNER TO postgres;

--
-- Name: demotime_event_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_event_id_seq OWNER TO postgres;

--
-- Name: demotime_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_event_id_seq OWNED BY demotime_event.id;


--
-- Name: demotime_eventtype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_eventtype (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    name character varying(128) NOT NULL,
    code character varying(50) NOT NULL
);


ALTER TABLE demotime_eventtype OWNER TO postgres;

--
-- Name: demotime_eventtype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_eventtype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_eventtype_id_seq OWNER TO postgres;

--
-- Name: demotime_eventtype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_eventtype_id_seq OWNED BY demotime_eventtype.id;


--
-- Name: demotime_follower; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_follower (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    review_id integer NOT NULL,
    user_id integer NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE demotime_follower OWNER TO postgres;

--
-- Name: demotime_follower_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_follower_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_follower_id_seq OWNER TO postgres;

--
-- Name: demotime_follower_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_follower_id_seq OWNED BY demotime_follower.id;


--
-- Name: demotime_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_group (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    name character varying(128) NOT NULL,
    slug character varying(50) NOT NULL,
    description text NOT NULL,
    group_type_id integer NOT NULL
);


ALTER TABLE demotime_group OWNER TO postgres;

--
-- Name: demotime_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_group_id_seq OWNER TO postgres;

--
-- Name: demotime_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_group_id_seq OWNED BY demotime_group.id;


--
-- Name: demotime_groupmember; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_groupmember (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    is_admin boolean NOT NULL,
    group_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE demotime_groupmember OWNER TO postgres;

--
-- Name: demotime_groupmember_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_groupmember_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_groupmember_id_seq OWNER TO postgres;

--
-- Name: demotime_groupmember_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_groupmember_id_seq OWNED BY demotime_groupmember.id;


--
-- Name: demotime_grouptype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_grouptype (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    name character varying(128) NOT NULL,
    slug character varying(50) NOT NULL
);


ALTER TABLE demotime_grouptype OWNER TO postgres;

--
-- Name: demotime_grouptype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_grouptype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_grouptype_id_seq OWNER TO postgres;

--
-- Name: demotime_grouptype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_grouptype_id_seq OWNED BY demotime_grouptype.id;


--
-- Name: demotime_issue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_issue (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    comment_id integer NOT NULL,
    created_by_id integer NOT NULL,
    resolved_by_id integer,
    review_id integer NOT NULL
);


ALTER TABLE demotime_issue OWNER TO postgres;

--
-- Name: demotime_issue_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_issue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_issue_id_seq OWNER TO postgres;

--
-- Name: demotime_issue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_issue_id_seq OWNED BY demotime_issue.id;


--
-- Name: demotime_message; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_message (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    message text NOT NULL,
    receipient_id integer NOT NULL,
    review_id integer,
    sender_id integer NOT NULL,
    thread_id integer,
    title character varying(1024) NOT NULL,
    bundle_id integer NOT NULL
);


ALTER TABLE demotime_message OWNER TO postgres;

--
-- Name: demotime_message_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_message_id_seq OWNER TO postgres;

--
-- Name: demotime_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_message_id_seq OWNED BY demotime_message.id;


--
-- Name: demotime_messagebundle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_messagebundle (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    read boolean NOT NULL,
    deleted boolean NOT NULL,
    owner_id integer NOT NULL,
    review_id integer
);


ALTER TABLE demotime_messagebundle OWNER TO postgres;

--
-- Name: demotime_messagebundle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_messagebundle_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_messagebundle_id_seq OWNER TO postgres;

--
-- Name: demotime_messagebundle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_messagebundle_id_seq OWNED BY demotime_messagebundle.id;


--
-- Name: demotime_project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_project (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    name character varying(128) NOT NULL,
    slug character varying(50) NOT NULL,
    description text NOT NULL,
    is_public boolean NOT NULL,
    token character varying(256) NOT NULL
);


ALTER TABLE demotime_project OWNER TO postgres;

--
-- Name: demotime_project_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_project_id_seq OWNER TO postgres;

--
-- Name: demotime_project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_project_id_seq OWNED BY demotime_project.id;


--
-- Name: demotime_projectgroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_projectgroup (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    is_admin boolean NOT NULL,
    group_id integer NOT NULL,
    project_id integer NOT NULL
);


ALTER TABLE demotime_projectgroup OWNER TO postgres;

--
-- Name: demotime_projectgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_projectgroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_projectgroup_id_seq OWNER TO postgres;

--
-- Name: demotime_projectgroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_projectgroup_id_seq OWNED BY demotime_projectgroup.id;


--
-- Name: demotime_projectmember; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_projectmember (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    is_admin boolean NOT NULL,
    project_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE demotime_projectmember OWNER TO postgres;

--
-- Name: demotime_projectmember_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_projectmember_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_projectmember_id_seq OWNER TO postgres;

--
-- Name: demotime_projectmember_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_projectmember_id_seq OWNED BY demotime_projectmember.id;


--
-- Name: demotime_reminder; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_reminder (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    reminder_type character varying(256) NOT NULL,
    remind_at timestamp with time zone NOT NULL,
    active boolean NOT NULL,
    review_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE demotime_reminder OWNER TO postgres;

--
-- Name: demotime_reminder_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_reminder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_reminder_id_seq OWNER TO postgres;

--
-- Name: demotime_reminder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_reminder_id_seq OWNED BY demotime_reminder.id;


--
-- Name: demotime_review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_review (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    title character varying(1024) NOT NULL,
    description text NOT NULL,
    case_link character varying(2048) NOT NULL,
    state character varying(128) NOT NULL,
    reviewer_state character varying(128) NOT NULL,
    is_public boolean NOT NULL,
    project_id integer NOT NULL,
    last_action_by_id integer NOT NULL
);


ALTER TABLE demotime_review OWNER TO postgres;

--
-- Name: demotime_review_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_review_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_review_id_seq OWNER TO postgres;

--
-- Name: demotime_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_review_id_seq OWNED BY demotime_review.id;


--
-- Name: demotime_reviewer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_reviewer (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    status character varying(128) NOT NULL,
    review_id integer NOT NULL,
    reviewer_id integer NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE demotime_reviewer OWNER TO postgres;

--
-- Name: demotime_reviewer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_reviewer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_reviewer_id_seq OWNER TO postgres;

--
-- Name: demotime_reviewer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_reviewer_id_seq OWNED BY demotime_reviewer.id;


--
-- Name: demotime_reviewrevision; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_reviewrevision (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    description text NOT NULL,
    review_id integer NOT NULL,
    number integer NOT NULL
);


ALTER TABLE demotime_reviewrevision OWNER TO postgres;

--
-- Name: demotime_reviewrevision_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_reviewrevision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_reviewrevision_id_seq OWNER TO postgres;

--
-- Name: demotime_reviewrevision_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_reviewrevision_id_seq OWNED BY demotime_reviewrevision.id;


--
-- Name: demotime_setting; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_setting (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    title character varying(128) NOT NULL,
    key character varying(128) NOT NULL,
    description text NOT NULL,
    raw_value text NOT NULL,
    setting_type character varying(32) NOT NULL,
    active boolean NOT NULL,
    project_id integer
);


ALTER TABLE demotime_setting OWNER TO postgres;

--
-- Name: demotime_setting_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_setting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_setting_id_seq OWNER TO postgres;

--
-- Name: demotime_setting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_setting_id_seq OWNED BY demotime_setting.id;


--
-- Name: demotime_userprofile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_userprofile (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    avatar character varying(100),
    bio text NOT NULL,
    display_name character varying(2048),
    user_id integer NOT NULL,
    user_type character varying(1024) NOT NULL
);


ALTER TABLE demotime_userprofile OWNER TO postgres;

--
-- Name: demotime_userprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_userprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_userprofile_id_seq OWNER TO postgres;

--
-- Name: demotime_userprofile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_userprofile_id_seq OWNED BY demotime_userprofile.id;


--
-- Name: demotime_userreviewstatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_userreviewstatus (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    read boolean NOT NULL,
    review_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE demotime_userreviewstatus OWNER TO postgres;

--
-- Name: demotime_userreviewstatus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_userreviewstatus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_userreviewstatus_id_seq OWNER TO postgres;

--
-- Name: demotime_userreviewstatus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_userreviewstatus_id_seq OWNED BY demotime_userreviewstatus.id;


--
-- Name: demotime_webhook; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE demotime_webhook (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    target character varying(1024) NOT NULL,
    trigger_event character varying(64) NOT NULL,
    project_id integer NOT NULL
);


ALTER TABLE demotime_webhook OWNER TO postgres;

--
-- Name: demotime_webhook_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE demotime_webhook_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE demotime_webhook_id_seq OWNER TO postgres;

--
-- Name: demotime_webhook_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE demotime_webhook_id_seq OWNED BY demotime_webhook.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE django_session OWNER TO postgres;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE django_site OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_site_id_seq OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


--
-- Name: registration_registrationprofile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE registration_registrationprofile (
    id integer NOT NULL,
    activation_key character varying(40) NOT NULL,
    user_id integer NOT NULL,
    activated boolean NOT NULL
);


ALTER TABLE registration_registrationprofile OWNER TO postgres;

--
-- Name: registration_registrationprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE registration_registrationprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE registration_registrationprofile_id_seq OWNER TO postgres;

--
-- Name: registration_registrationprofile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE registration_registrationprofile_id_seq OWNED BY registration_registrationprofile.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_attachment ALTER COLUMN id SET DEFAULT nextval('demotime_attachment_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_comment ALTER COLUMN id SET DEFAULT nextval('demotime_comment_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_commentthread ALTER COLUMN id SET DEFAULT nextval('demotime_commentthread_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_creator ALTER COLUMN id SET DEFAULT nextval('demotime_creator_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_event ALTER COLUMN id SET DEFAULT nextval('demotime_event_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_eventtype ALTER COLUMN id SET DEFAULT nextval('demotime_eventtype_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_follower ALTER COLUMN id SET DEFAULT nextval('demotime_follower_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_group ALTER COLUMN id SET DEFAULT nextval('demotime_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_groupmember ALTER COLUMN id SET DEFAULT nextval('demotime_groupmember_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_grouptype ALTER COLUMN id SET DEFAULT nextval('demotime_grouptype_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_issue ALTER COLUMN id SET DEFAULT nextval('demotime_issue_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_message ALTER COLUMN id SET DEFAULT nextval('demotime_message_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_messagebundle ALTER COLUMN id SET DEFAULT nextval('demotime_messagebundle_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_project ALTER COLUMN id SET DEFAULT nextval('demotime_project_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_projectgroup ALTER COLUMN id SET DEFAULT nextval('demotime_projectgroup_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_projectmember ALTER COLUMN id SET DEFAULT nextval('demotime_projectmember_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_reminder ALTER COLUMN id SET DEFAULT nextval('demotime_reminder_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_review ALTER COLUMN id SET DEFAULT nextval('demotime_review_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_reviewer ALTER COLUMN id SET DEFAULT nextval('demotime_reviewer_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_reviewrevision ALTER COLUMN id SET DEFAULT nextval('demotime_reviewrevision_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_setting ALTER COLUMN id SET DEFAULT nextval('demotime_setting_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_userprofile ALTER COLUMN id SET DEFAULT nextval('demotime_userprofile_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_userreviewstatus ALTER COLUMN id SET DEFAULT nextval('demotime_userreviewstatus_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_webhook ALTER COLUMN id SET DEFAULT nextval('demotime_webhook_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY registration_registrationprofile ALTER COLUMN id SET DEFAULT nextval('registration_registrationprofile_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	22	add_logentry
2	Can change log entry	22	change_logentry
3	Can delete log entry	22	delete_logentry
4	Can add permission	23	add_permission
5	Can change permission	23	change_permission
6	Can delete permission	23	delete_permission
7	Can add group	24	add_group
8	Can change group	24	change_group
9	Can delete group	24	delete_group
10	Can add user	25	add_user
11	Can change user	25	change_user
12	Can delete user	25	delete_user
13	Can add content type	26	add_contenttype
14	Can change content type	26	change_contenttype
15	Can delete content type	26	delete_contenttype
16	Can add session	27	add_session
17	Can change session	27	change_session
18	Can delete session	27	delete_session
19	Can add site	28	add_site
20	Can change site	28	change_site
21	Can delete site	28	delete_site
22	Can add setting	14	add_setting
23	Can change setting	14	change_setting
24	Can delete setting	14	delete_setting
25	Can add event type	29	add_eventtype
26	Can change event type	29	change_eventtype
27	Can delete event type	29	delete_eventtype
28	Can add event	30	add_event
29	Can change event	30	change_event
30	Can delete event	30	delete_event
31	Can add attachment	10	add_attachment
32	Can change attachment	10	change_attachment
33	Can delete attachment	10	delete_attachment
34	Can add message bundle	21	add_messagebundle
35	Can change message bundle	21	change_messagebundle
36	Can delete message bundle	21	delete_messagebundle
37	Can add message	4	add_message
38	Can change message	4	change_message
39	Can delete message	4	delete_message
40	Can add reminder	18	add_reminder
41	Can change reminder	18	change_reminder
42	Can delete reminder	18	delete_reminder
43	Can add follower	16	add_follower
44	Can change follower	16	change_follower
45	Can delete follower	16	delete_follower
46	Can add reviewer	17	add_reviewer
47	Can change reviewer	17	change_reviewer
48	Can delete reviewer	17	delete_reviewer
49	Can add group type	7	add_grouptype
50	Can change group type	7	change_grouptype
51	Can delete group type	7	delete_grouptype
52	Can add group	11	add_group
53	Can change group	11	change_group
54	Can delete group	11	delete_group
55	Can add group member	2	add_groupmember
56	Can change group member	2	change_groupmember
57	Can delete group member	2	delete_groupmember
58	Can add project	1	add_project
59	Can change project	1	change_project
60	Can delete project	1	delete_project
61	Can add project group	9	add_projectgroup
62	Can change project group	9	change_projectgroup
63	Can delete project group	9	delete_projectgroup
64	Can add project member	19	add_projectmember
65	Can change project member	19	change_projectmember
66	Can delete project member	19	delete_projectmember
67	Can add web hook	5	add_webhook
68	Can change web hook	5	change_webhook
69	Can delete web hook	5	delete_webhook
70	Can add user proxy	25	add_userproxy
71	Can change user proxy	25	change_userproxy
72	Can delete user proxy	25	delete_userproxy
73	Can add user profile	8	add_userprofile
74	Can change user profile	8	change_userprofile
75	Can delete user profile	8	delete_userprofile
76	Can add user review status	13	add_userreviewstatus
77	Can change user review status	13	change_userreviewstatus
78	Can delete user review status	13	delete_userreviewstatus
79	Can add comment thread	3	add_commentthread
80	Can change comment thread	3	change_commentthread
81	Can delete comment thread	3	delete_commentthread
82	Can add comment	12	add_comment
83	Can change comment	12	change_comment
84	Can delete comment	12	delete_comment
85	Can add review	6	add_review
86	Can change review	6	change_review
87	Can delete review	6	delete_review
88	Can add review revision	15	add_reviewrevision
89	Can change review revision	15	change_reviewrevision
90	Can delete review revision	15	delete_reviewrevision
91	Can add registration profile	31	add_registrationprofile
92	Can change registration profile	31	change_registrationprofile
93	Can delete registration profile	31	delete_registrationprofile
94	Can add issue	32	add_issue
95	Can change issue	32	change_issue
96	Can delete issue	32	delete_issue
97	Can add creator	33	add_creator
98	Can change creator	33	change_creator
99	Can delete creator	33	delete_creator
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_permission_id_seq', 99, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1		\N	f	demotime_sys				f	t	2016-10-16 19:48:22.841794+00
4	pbkdf2_sha256$24000$NDZWXcH3ZuOV$APE8AOqIb/HuDAW52LbMALS1wMQaMRDmWgZK+N3vO4U=	\N	f	moira.brown			moira.brown@domestiquestudios.com	f	t	2016-10-16 20:18:06.842783+00
9	pbkdf2_sha256$24000$XVmXybOwpSi9$gGrVof8ssmQ4kv2R0PI/HfsJvTCk8dIySS3d/Pz2F8M=	\N	f	madison.li			madison.li@domestiquestudios.com	f	t	2016-10-16 20:18:07.251922+00
10	pbkdf2_sha256$24000$L4LOyUxcrBf4$LErlQaqHuoHn6wYbo2Ig7j6kDxZ60mj1CGT74DoBR7g=	\N	f	seagrave.holmes			seagrave.holmes@domestiquestudios.com	f	t	2016-10-16 20:18:07.325721+00
11	pbkdf2_sha256$24000$7QEoU4bhzbzs$bs2yHR2GDVUO4GmmMIqLgNedeImK2GHTtUzMtrg/MJE=	\N	f	christie.young			christie.young@domestiquestudios.com	f	t	2016-10-16 20:18:07.403496+00
12	pbkdf2_sha256$24000$b4uZy8OxwmfS$14WzDKC/P0iSOt1M/M37zBOp5K4bUg9uPjjybXWTKaM=	\N	f	cindy.cantelli			cindy.cantelli@domestiquestudios.com	f	t	2016-10-16 20:18:07.48439+00
13	pbkdf2_sha256$24000$4vaeJHLVxD6h$rmeb7txktx7sNEKNUbET5OPtp3Kpsa+RvqQWMkz/frk=	\N	f	ted.strayer			ted.strayer@domestiquestudios.com	f	t	2016-10-16 20:18:07.557856+00
14	pbkdf2_sha256$24000$Co90THx1umdB$86Jq79UXUgX46nDLOAO2F1gbBX1u3fOK6hTsz85YsY8=	\N	f	manya.vargas			manya.vargas@domestiquestudios.com	f	t	2016-10-16 20:18:07.649079+00
15	pbkdf2_sha256$24000$4LSfzOLOBPpB$evCI/ovTqmpQqxUx4iahTwNbAksYL0HlkjCDRSS+110=	\N	f	colin.moriarty			colin.moriarty@domestiquestudios.com	f	t	2016-10-16 20:18:07.728315+00
16	pbkdf2_sha256$24000$FAjoKMj3PS5K$Q5cGwLgY3bKM3meBK+4XRuSmlBRsPX4sWFOL90sN8Go=	\N	f	rosa.meitner			rosa.meitner@domestiquestudios.com	f	t	2016-10-16 20:18:07.805667+00
17	pbkdf2_sha256$24000$AwdQZKyAKHDX$iXNi2e+RoAbu0VCbe/CuCySgcEoiFZ5EKB1EGcdmX0w=	\N	f	nathaniel.vargas			nathaniel.vargas@domestiquestudios.com	f	t	2016-10-16 20:18:07.893479+00
18	pbkdf2_sha256$24000$7fgbqPXhglNa$wivX1ta1iaTIRjKaHQS2wiL8j471q0H3mzksWHMA7J4=	\N	f	lucas.simms			lucas.simms@domestiquestudios.com	f	t	2016-10-16 20:18:07.971731+00
5	pbkdf2_sha256$24000$buzPL1jvmQWH$XspPAt8Ek6B+dYJ6ATs5YhuqMIkiTLrV9kIrShkj+GE=	2016-10-16 20:24:30.992789+00	f	moriarty.senior			moriarty.senior@domestiquestudios.com	f	t	2016-10-16 20:18:06.942396+00
8	pbkdf2_sha256$24000$gGV8DaucRtS6$/hrHJZB65wtMmvIS6FzZHyr4VM36W/VQYkG5Z6zqQ3k=	2016-10-16 20:33:58.252911+00	f	billy.creel			billy.creel@domestiquestudios.com	f	t	2016-10-16 20:18:07.179215+00
2	pbkdf2_sha256$30000$LEYEgZYlnXN6$HuXKTLLVaqGYYA7zLwHRn3T3+ZmEyUPfY6iZ8MmZLE4=	2017-01-09 02:50:30.069552+00	t	admin			admin@domestiquestudios.com	t	t	2016-10-16 19:50:00.146932+00
6	pbkdf2_sha256$30000$bDDTCdzmbvSi$2mw4i1one8+PApm80s/7Tq0XLr3AXVtieAtVK6h0dzs=	2017-01-09 00:41:29.127573+00	f	leo.stahl			leo.stahl@domestiquestudios.com	f	t	2016-10-16 20:18:07.021485+00
7	pbkdf2_sha256$30000$83Lmw3PncTHT$2aAjDTTCgh3K5gx6Ufqyn7DF4aVJ9SLUju4Jmx+VR5I=	2017-01-09 00:42:14.216541+00	f	lucy.west			lucy.west@domestiquestudios.com	f	t	2016-10-16 20:18:07.101769+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_id_seq', 18, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: demotime_attachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_attachment (id, created, modified, attachment, object_id, content_type_id, attachment_type, description, sort_order) FROM stdin;
\.


--
-- Name: demotime_attachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_attachment_id_seq', 1, false);


--
-- Data for Name: demotime_comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_comment (id, created, modified, comment, commenter_id, thread_id) FROM stdin;
2	2016-10-16 20:34:44.629906+00	2016-10-16 20:34:44.629971+00	This is a test comment!<div><br></div><div><br></div><img src="https://media4.giphy.com/media/QMkPpxPDYY0fu/giphy.gif">	2	2
3	2016-10-16 20:36:26.587356+00	2016-10-16 20:36:26.587415+00	Another test comment!&nbsp;<img class="emoji" width="30" height="30" src="http://local.demotime.com:8033/static/images/emoji/smiley.png"><div><br></div><div><br></div><img src="https://media3.giphy.com/media/s2qXK8wAvkHTO/giphy.gif">	2	3
4	2016-10-16 20:36:44.693991+00	2016-10-16 20:36:44.694204+00	A test reply!&nbsp;<img class="emoji" width="30" height="30" src="http://local.demotime.com:8033/static/images/emoji/beers.png">	8	3
5	2017-01-09 00:42:01.74412+00	2017-01-09 00:42:01.744161+00	I have issues with this demo	6	4
6	2017-01-09 00:42:26.977127+00	2017-01-09 00:42:26.977161+00	I'm pretty cool with this.	7	5
\.


--
-- Name: demotime_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_comment_id_seq', 6, true);


--
-- Data for Name: demotime_commentthread; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_commentthread (id, created, modified, review_revision_id) FROM stdin;
2	2016-10-16 20:34:44.612399+00	2016-10-16 20:34:44.612453+00	2
3	2016-10-16 20:36:26.568787+00	2016-10-16 20:36:26.568856+00	3
4	2017-01-09 00:42:01.728643+00	2017-01-09 00:42:01.728681+00	6
5	2017-01-09 00:42:26.960521+00	2017-01-09 00:42:26.960555+00	6
\.


--
-- Name: demotime_commentthread_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_commentthread_id_seq', 5, true);


--
-- Data for Name: demotime_creator; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_creator (id, created, modified, active, review_id, user_id) FROM stdin;
1	2017-01-08 22:10:50.177628+00	2017-01-08 22:10:50.177696+00	t	3	2
2	2017-01-08 22:10:50.188886+00	2017-01-08 22:10:50.188964+00	t	2	2
3	2017-01-09 04:42:22.012204+00	2017-01-09 04:42:22.01224+00	t	4	2
4	2017-01-09 04:42:22.03167+00	2017-01-09 04:42:22.031709+00	t	4	8
5	2017-01-09 04:43:01.694895+00	2017-01-09 04:43:01.694955+00	t	5	2
6	2017-01-09 04:43:01.725507+00	2017-01-09 04:43:01.725562+00	t	5	8
7	2017-01-09 00:41:17.084196+00	2017-01-09 00:41:17.084232+00	t	6	2
8	2017-01-09 00:41:17.109581+00	2017-01-09 00:41:17.109637+00	t	6	8
\.


--
-- Name: demotime_creator_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_creator_id_seq', 8, true);


--
-- Data for Name: demotime_event; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_event (id, created, modified, object_id, related_type, content_type_id, project_id, event_type_id, user_id, review_id) FROM stdin;
13	2016-10-16 20:33:31.344219+00	2016-10-16 20:33:31.344252+00	2	review	6	3	1	2	2
14	2016-10-16 20:33:31.374986+00	2016-10-16 20:33:31.375019+00	4	reviewer	17	3	13	2	2
15	2016-10-16 20:33:31.440881+00	2016-10-16 20:33:31.440929+00	4	follower	16	3	15	2	2
16	2016-10-16 20:34:02.985187+00	2016-10-16 20:34:02.98522+00	4	reviewer	17	3	10	8	2
17	2016-10-16 20:34:03.106993+00	2016-10-16 20:34:03.107035+00	2	review	6	3	6	2	2
18	2016-10-16 20:34:45.097639+00	2016-10-16 20:34:45.097673+00	2	comment	12	3	9	2	2
19	2016-10-16 20:34:57.2368+00	2016-10-16 20:34:57.236831+00	2	review	6	3	3	2	2
20	2016-10-16 20:35:30.983962+00	2016-10-16 20:35:30.984018+00	3	review	6	2	1	2	3
21	2016-10-16 20:35:31.032489+00	2016-10-16 20:35:31.032593+00	5	reviewer	17	2	13	2	3
22	2016-10-16 20:35:31.122134+00	2016-10-16 20:35:31.122188+00	5	follower	16	2	15	2	3
23	2016-10-16 20:35:42.848725+00	2016-10-16 20:35:42.84876+00	5	reviewer	17	2	10	8	3
24	2016-10-16 20:35:42.969221+00	2016-10-16 20:35:42.969288+00	3	review	6	2	6	2	3
25	2016-10-16 20:36:26.908015+00	2016-10-16 20:36:26.908051+00	3	comment	12	2	9	2	3
26	2016-10-16 20:36:45.049156+00	2016-10-16 20:36:45.049194+00	4	comment	12	2	9	8	3
27	2016-10-16 20:36:54.295251+00	2016-10-16 20:36:54.295285+00	3	review	6	2	3	2	3
28	2017-01-09 04:43:02.31833+00	2017-01-09 04:43:02.31849+00	5	review	6	3	1	2	5
29	2017-01-09 04:43:02.891778+00	2017-01-09 04:43:02.891819+00	8	reviewer	17	3	13	2	5
30	2017-01-09 04:43:02.910718+00	2017-01-09 04:43:02.910754+00	9	reviewer	17	3	13	2	5
31	2017-01-09 04:43:02.926297+00	2017-01-09 04:43:02.926335+00	8	follower	16	3	15	2	5
32	2017-01-09 04:43:02.93969+00	2017-01-09 04:43:02.939726+00	9	follower	16	3	15	2	5
33	2017-01-09 04:43:05.518306+00	2017-01-09 04:43:05.518344+00	5	review	6	3	17	2	5
34	2017-01-09 00:41:17.731999+00	2017-01-09 00:41:17.732033+00	6	review	6	3	1	2	6
35	2017-01-09 00:41:18.380412+00	2017-01-09 00:41:18.380494+00	10	reviewer	17	3	13	2	6
36	2017-01-09 00:41:18.398481+00	2017-01-09 00:41:18.398525+00	11	reviewer	17	3	13	2	6
37	2017-01-09 00:41:18.417473+00	2017-01-09 00:41:18.417558+00	12	reviewer	17	3	13	2	6
38	2017-01-09 00:41:18.437247+00	2017-01-09 00:41:18.437299+00	10	follower	16	3	15	2	6
39	2017-01-09 00:41:18.454606+00	2017-01-09 00:41:18.454702+00	11	follower	16	3	15	2	6
40	2017-01-09 00:41:36.959866+00	2017-01-09 00:41:36.959928+00	10	reviewer	17	3	11	6	6
41	2017-01-09 00:42:01.764666+00	2017-01-09 00:42:01.764702+00	5	comment	12	3	9	6	6
42	2017-01-09 00:42:02.251143+00	2017-01-09 00:42:02.251187+00	1	issue	32	3	20	6	6
43	2017-01-09 00:42:26.998728+00	2017-01-09 00:42:26.998774+00	6	comment	12	3	9	7	6
44	2017-01-09 00:42:27.578692+00	2017-01-09 00:42:27.578731+00	2	issue	32	3	20	7	6
45	2017-01-09 00:42:29.308915+00	2017-01-09 00:42:29.308953+00	2	issue	32	3	21	7	6
46	2017-01-09 00:42:32.621378+00	2017-01-09 00:42:32.62146+00	12	reviewer	17	3	10	7	6
\.


--
-- Name: demotime_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_event_id_seq', 46, true);


--
-- Data for Name: demotime_eventtype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_eventtype (id, created, modified, name, code) FROM stdin;
1	2016-10-16 19:48:28.947826+00	2016-10-16 19:48:28.94805+00	Demo Created	demo-created
2	2016-10-16 19:48:28.951043+00	2016-10-16 19:48:28.951138+00	Demo Opened	demo-opened
3	2016-10-16 19:48:28.952298+00	2016-10-16 19:48:28.952339+00	Demo Closed	demo-closed
4	2016-10-16 19:48:28.953322+00	2016-10-16 19:48:28.953358+00	Demo Aborted	demo-aborted
5	2016-10-16 19:48:28.954481+00	2016-10-16 19:48:28.954517+00	Demo Updated	demo-updated
6	2016-10-16 19:48:28.955414+00	2016-10-16 19:48:28.955449+00	Demo Approved	demo-approved
7	2016-10-16 19:48:28.956362+00	2016-10-16 19:48:28.956402+00	Demo Rejected	demo-rejected
8	2016-10-16 19:48:28.959559+00	2016-10-16 19:48:28.959599+00	Demo Reviewing	demo-reviewing
9	2016-10-16 19:48:28.960374+00	2016-10-16 19:48:28.960402+00	Comment Added	comment-added
10	2016-10-16 19:48:28.961075+00	2016-10-16 19:48:28.9611+00	Reviewer Approved	reviewer-approved
11	2016-10-16 19:48:28.961863+00	2016-10-16 19:48:28.961889+00	Reviewer Rejected	reviewer-rejected
12	2016-10-16 19:48:28.962683+00	2016-10-16 19:48:28.962722+00	Reviewer Reset	reviewer-reset
13	2016-10-16 19:48:28.964771+00	2016-10-16 19:48:28.964823+00	Reviewer Added	reviewer-added
14	2016-10-16 19:48:28.96688+00	2016-10-16 19:48:28.967022+00	Reviewer Removed	reviewer-removed
15	2016-10-16 19:48:28.969795+00	2016-10-16 19:48:28.970071+00	Follower Added	follower-added
16	2016-10-16 19:48:28.972641+00	2016-10-16 19:48:28.972716+00	Follower Removed	follower-removed
17	2017-01-08 22:10:49.315669+00	2017-01-08 22:10:49.315704+00	Demo Paused	demo-paused
18	2017-01-08 22:10:50.204132+00	2017-01-08 22:10:50.204174+00	Owner Added	owner-added
19	2017-01-08 22:10:50.207313+00	2017-01-08 22:10:50.207429+00	Owner Removed	owner-removed
20	2017-01-08 22:10:50.855304+00	2017-01-08 22:10:50.855522+00	Issue Created	issue-created
21	2017-01-08 22:10:50.86063+00	2017-01-08 22:10:50.860686+00	Issue Resolved	issue-resolved
\.


--
-- Name: demotime_eventtype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_eventtype_id_seq', 21, true);


--
-- Data for Name: demotime_follower; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_follower (id, created, modified, review_id, user_id, is_active) FROM stdin;
4	2016-10-16 20:33:31.424493+00	2016-10-16 20:33:31.424528+00	2	6	t
5	2016-10-16 20:35:31.098834+00	2016-10-16 20:35:31.098978+00	3	11	t
6	2017-01-09 04:42:22.424927+00	2017-01-09 04:42:22.438046+00	4	11	t
7	2017-01-09 04:42:22.507174+00	2017-01-09 04:42:22.521998+00	4	12	t
8	2017-01-09 04:43:02.833037+00	2017-01-09 04:43:02.833105+00	5	11	t
9	2017-01-09 04:43:02.833037+00	2017-01-09 04:43:02.833105+00	5	12	t
10	2017-01-09 00:41:18.321197+00	2017-01-09 00:41:18.321229+00	6	10	t
11	2017-01-09 00:41:18.321197+00	2017-01-09 00:41:18.321229+00	6	13	t
\.


--
-- Name: demotime_follower_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_follower_id_seq', 11, true);


--
-- Data for Name: demotime_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_group (id, created, modified, name, slug, description, group_type_id) FROM stdin;
1	2016-10-16 19:48:26.529747+00	2016-10-16 19:48:26.529782+00	Default Group	default-group	Default DemoTime Group	1
2	2016-10-16 19:54:49.137351+00	2016-10-16 19:54:49.137392+00	Quality Assurance	quality-assurance	QA	2
3	2016-10-16 19:55:52.352992+00	2016-10-16 19:55:52.353027+00	Product	product	Product	3
4	2016-10-16 19:56:08.903807+00	2016-10-16 19:56:08.903843+00	Development	development	Development	4
\.


--
-- Name: demotime_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_group_id_seq', 4, true);


--
-- Data for Name: demotime_groupmember; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_groupmember (id, created, modified, is_admin, group_id, user_id) FROM stdin;
1	2016-10-16 20:18:06.917085+00	2016-10-16 20:18:06.917119+00	t	3	4
2	2016-10-16 20:18:06.995561+00	2016-10-16 20:18:06.995616+00	t	3	5
3	2016-10-16 20:18:07.075212+00	2016-10-16 20:18:07.075351+00	t	3	6
4	2016-10-16 20:18:07.151603+00	2016-10-16 20:18:07.151658+00	t	3	7
5	2016-10-16 20:18:07.226552+00	2016-10-16 20:18:07.226586+00	t	3	8
6	2016-10-16 20:18:07.300377+00	2016-10-16 20:18:07.30043+00	t	3	9
7	2016-10-16 20:18:07.378818+00	2016-10-16 20:18:07.378874+00	t	3	10
8	2016-10-16 20:18:07.458943+00	2016-10-16 20:18:07.458997+00	t	3	11
9	2016-10-16 20:18:07.532617+00	2016-10-16 20:18:07.532672+00	t	3	12
10	2016-10-16 20:18:07.623433+00	2016-10-16 20:18:07.623478+00	t	3	13
11	2016-10-16 20:18:07.70269+00	2016-10-16 20:18:07.702745+00	t	3	14
12	2016-10-16 20:18:07.780289+00	2016-10-16 20:18:07.780324+00	t	3	15
13	2016-10-16 20:18:07.863269+00	2016-10-16 20:18:07.863304+00	t	3	16
14	2016-10-16 20:18:07.945677+00	2016-10-16 20:18:07.945733+00	t	3	17
15	2016-10-16 20:18:08.023302+00	2016-10-16 20:18:08.023355+00	t	3	18
\.


--
-- Name: demotime_groupmember_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_groupmember_id_seq', 15, true);


--
-- Data for Name: demotime_grouptype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_grouptype (id, created, modified, name, slug) FROM stdin;
1	2016-10-16 19:48:26.528339+00	2016-10-16 19:48:26.528382+00	Default Group Type	default-group-type
2	2016-10-16 19:54:03.501759+00	2016-10-16 19:54:03.501852+00	Quality Assurance	quality-assurance
3	2016-10-16 19:55:07.794993+00	2016-10-16 19:55:07.795027+00	Product	product
4	2016-10-16 19:55:20.966371+00	2016-10-16 19:55:20.966455+00	Development	development
\.


--
-- Name: demotime_grouptype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_grouptype_id_seq', 4, true);


--
-- Data for Name: demotime_issue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_issue (id, created, modified, comment_id, created_by_id, resolved_by_id, review_id) FROM stdin;
1	2017-01-09 00:42:02.234907+00	2017-01-09 00:42:02.234942+00	5	6	\N	6
2	2017-01-09 00:42:27.560715+00	2017-01-09 00:42:29.291709+00	6	7	7	6
\.


--
-- Name: demotime_issue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_issue_id_seq', 2, true);


--
-- Data for Name: demotime_message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_message (id, created, modified, message, receipient_id, review_id, sender_id, thread_id, title, bundle_id) FROM stdin;
16	2016-10-16 20:33:31.641166+00	2016-10-16 20:33:31.641198+00	\n\n\n\n<p>\n\n    \n        A new demo has been created and assigned to you: <a href="http://local.demotime.com:8033/reviews/demotime/review/2/rev/1/">Test Demo 1</a>.\n    \n\n</p>\n\n\n\n	8	2	1	\N	New Review: Test Demo 1	8
17	2016-10-16 20:33:31.832482+00	2016-10-16 20:33:31.832521+00	\n\n\n\n<p>\n\n    \n        You have been assigned as a follower on <a href="http://local.demotime.com:8033/reviews/demotime/review/2/rev/1/">Test Demo 1</a>.\n    \n\n</p>\n\n\n\n	6	2	1	\N	New Review: Test Demo 1	9
18	2016-10-16 20:34:03.0682+00	2016-10-16 20:34:03.068255+00	\n\n\n\n<p>\nYour demo, <a href="http://local.demotime.com:8033/reviews/demotime/review/2/rev/1/">Test Demo 1</a>, has been approved! You can now proceed to close this demo, or add further content to it if you wish!\n</p>\n\n\n\n	2	2	1	\N	"Test Demo 1" has been Approved!	10
19	2016-10-16 20:34:44.843295+00	2016-10-16 20:34:44.843353+00	\n\n\n\n<p>\nAdmin just added a new comment to <a href="http://local.demotime.com:8033/reviews/demotime/review/2/rev/1/#2">Test Demo 1</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        This is a test comment!<div><br></div><div><br></div><img src="https://media4.giphy.com/media/QMkPpxPDYY0fu/giphy.gif">\n    </blockquote>\n    \n\n\n\n\n	8	2	1	2	New Comment on Test Demo 1	8
20	2016-10-16 20:34:45.058078+00	2016-10-16 20:34:45.058171+00	\n\n\n\n<p>\nAdmin just added a new comment to <a href="http://local.demotime.com:8033/reviews/demotime/review/2/rev/1/#2">Test Demo 1</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        This is a test comment!<div><br></div><div><br></div><img src="https://media4.giphy.com/media/QMkPpxPDYY0fu/giphy.gif">\n    </blockquote>\n    \n\n\n\n\n	6	2	1	2	New Comment on Test Demo 1	9
21	2016-10-16 20:34:57.280019+00	2016-10-16 20:34:57.280052+00	\n\n\n\n<p>The demo, <a href="http://local.demotime.com:8033/reviews/demotime/review/2/rev/1/">Test Demo 1</a>, that you're reviewing is now closed.</p>\n\n\n\n	8	2	1	\N	"Test Demo 1" has been Closed	8
22	2016-10-16 20:34:57.392383+00	2016-10-16 20:34:57.392424+00	\n\n\n\n<p>The demo, <a href="http://local.demotime.com:8033/reviews/demotime/review/2/rev/1/">Test Demo 1</a>, that you're following is now closed.</p>\n\n\n\n	6	2	1	\N	"Test Demo 1" has been Closed	9
23	2016-10-16 20:35:31.25003+00	2016-10-16 20:35:31.250063+00	\n\n\n\n<p>\n\n    \n        A new demo has been created and assigned to you: <a href="http://local.demotime.com:8033/reviews/domestique-studios/review/3/rev/1/">Test Demo 2</a>.\n    \n\n</p>\n\n\n\n	8	3	1	\N	New Review: Test Demo 2	11
24	2016-10-16 20:35:31.400798+00	2016-10-16 20:35:31.400833+00	\n\n\n\n<p>\n\n    \n        You have been assigned as a follower on <a href="http://local.demotime.com:8033/reviews/domestique-studios/review/3/rev/1/">Test Demo 2</a>.\n    \n\n</p>\n\n\n\n	11	3	1	\N	New Review: Test Demo 2	12
25	2016-10-16 20:35:42.92855+00	2016-10-16 20:35:42.928607+00	\n\n\n\n<p>\nYour demo, <a href="http://local.demotime.com:8033/reviews/domestique-studios/review/3/rev/1/">Test Demo 2</a>, has been approved! You can now proceed to close this demo, or add further content to it if you wish!\n</p>\n\n\n\n	2	3	1	\N	"Test Demo 2" has been Approved!	13
26	2016-10-16 20:36:26.741079+00	2016-10-16 20:36:26.741133+00	\n\n\n\n<p>\nAdmin just added a new comment to <a href="http://local.demotime.com:8033/reviews/domestique-studios/review/3/rev/1/#3">Test Demo 2</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        Another test comment!&nbsp;<img class="emoji" width="30" height="30" src="http://local.demotime.com:8033/static/images/emoji/smiley.png"><div><br></div><div><br></div><img src="https://media3.giphy.com/media/s2qXK8wAvkHTO/giphy.gif">\n    </blockquote>\n    \n\n\n\n\n	8	3	1	3	New Comment on Test Demo 2	11
27	2016-10-16 20:36:26.858639+00	2016-10-16 20:36:26.858671+00	\n\n\n\n<p>\nAdmin just added a new comment to <a href="http://local.demotime.com:8033/reviews/domestique-studios/review/3/rev/1/#3">Test Demo 2</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        Another test comment!&nbsp;<img class="emoji" width="30" height="30" src="http://local.demotime.com:8033/static/images/emoji/smiley.png"><div><br></div><div><br></div><img src="https://media3.giphy.com/media/s2qXK8wAvkHTO/giphy.gif">\n    </blockquote>\n    \n\n\n\n\n	11	3	1	3	New Comment on Test Demo 2	12
28	2016-10-16 20:36:44.820211+00	2016-10-16 20:36:44.820281+00	\n\n\n\n<p>\nBilly Creel just added a new comment to <a href="http://local.demotime.com:8033/reviews/domestique-studios/review/3/rev/1/#4">Test Demo 2</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        A test reply!&nbsp;<img class="emoji" width="30" height="30" src="http://local.demotime.com:8033/static/images/emoji/beers.png">\n    </blockquote>\n    \n\n\n\n\n	11	3	1	3	New Comment on Test Demo 2	12
29	2016-10-16 20:36:45.00288+00	2016-10-16 20:36:45.003219+00	\n\n\n\n<p>\nBilly Creel just added a new comment to <a href="http://local.demotime.com:8033/reviews/domestique-studios/review/3/rev/1/#4">Test Demo 2</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        A test reply!&nbsp;<img class="emoji" width="30" height="30" src="http://local.demotime.com:8033/static/images/emoji/beers.png">\n    </blockquote>\n    \n\n\n\n\n	2	3	1	3	New Comment on Test Demo 2	13
30	2016-10-16 20:36:54.334226+00	2016-10-16 20:36:54.334257+00	\n\n\n\n<p>The demo, <a href="http://local.demotime.com:8033/reviews/domestique-studios/review/3/rev/1/">Test Demo 2</a>, that you're following is now closed.</p>\n\n\n\n	11	3	1	\N	"Test Demo 2" has been Closed	12
31	2016-10-16 20:36:54.402764+00	2016-10-16 20:36:54.402798+00	\n\n\n\n<p>The demo, <a href="http://local.demotime.com:8033/reviews/domestique-studios/review/3/rev/1/">Test Demo 2</a>, that you're reviewing is now closed.</p>\n\n\n\n	8	3	1	\N	"Test Demo 2" has been Closed	11
32	2017-01-09 04:42:22.147568+00	2017-01-09 04:42:22.14763+00	\n\n\n\n<p>\n    You have been added as a owner on <a href="http://local.demotime.com:8033/reviews/demotime/review/4/rev/1/">Draft Demo</a>!\n</p>\n\n\n\n	8	4	1	\N	You have been added as an owner of Draft Demo	14
33	2017-01-09 04:43:01.792359+00	2017-01-09 04:43:01.792427+00	\n\n\n\n<p>\n    You have been added as a owner on <a href="http://local.demotime.com:8033/reviews/demotime/review/5/rev/1/">Paused Demo</a>!\n</p>\n\n\n\n	8	5	1	\N	You have been added as an owner of Paused Demo	15
34	2017-01-09 04:43:02.384281+00	2017-01-09 04:43:02.384344+00	\n\n\n\n<p>\n\n    \n        A new demo has been created and assigned to you: <a href="http://local.demotime.com:8033/reviews/demotime/review/5/rev/1/">Paused Demo</a>.\n    \n\n</p>\n\n\n\n	7	5	1	\N	New Review: Paused Demo	16
35	2017-01-09 04:43:02.459106+00	2017-01-09 04:43:02.45917+00	\n\n\n\n<p>\n\n    \n        A new demo has been created and assigned to you: <a href="http://local.demotime.com:8033/reviews/demotime/review/5/rev/1/">Paused Demo</a>.\n    \n\n</p>\n\n\n\n	18	5	1	\N	New Review: Paused Demo	17
36	2017-01-09 04:43:02.532471+00	2017-01-09 04:43:02.532529+00	\n\n\n\n<p>\n\n    \n        You have been assigned as a follower on <a href="http://local.demotime.com:8033/reviews/demotime/review/5/rev/1/">Paused Demo</a>.\n    \n\n</p>\n\n\n\n	11	5	1	\N	New Review: Paused Demo	18
37	2017-01-09 04:43:02.60361+00	2017-01-09 04:43:02.60365+00	\n\n\n\n<p>\n\n    \n        You have been assigned as a follower on <a href="http://local.demotime.com:8033/reviews/demotime/review/5/rev/1/">Paused Demo</a>.\n    \n\n</p>\n\n\n\n	12	5	1	\N	New Review: Paused Demo	19
38	2017-01-09 04:43:05.56273+00	2017-01-09 04:43:05.56277+00	\n\n\n\n<p>The demo, <a href="http://local.demotime.com:8033/reviews/demotime/review/5/rev/1/">Paused Demo</a>, that you're following is now paused.</p>\n\n\n\n	11	5	1	\N	"Paused Demo" has been Paused	18
39	2017-01-09 04:43:05.625214+00	2017-01-09 04:43:05.625256+00	\n\n\n\n<p>The demo, <a href="http://local.demotime.com:8033/reviews/demotime/review/5/rev/1/">Paused Demo</a>, that you're reviewing is now paused.</p>\n\n\n\n	18	5	1	\N	"Paused Demo" has been Paused	17
40	2017-01-09 04:43:05.683329+00	2017-01-09 04:43:05.683364+00	\n\n\n\n<p>The demo, <a href="http://local.demotime.com:8033/reviews/demotime/review/5/rev/1/">Paused Demo</a>, that you're reviewing is now paused.</p>\n\n\n\n	7	5	1	\N	"Paused Demo" has been Paused	16
41	2017-01-09 04:43:05.728176+00	2017-01-09 04:43:05.728209+00	\n\n\n\n<p>The demo, <a href="http://local.demotime.com:8033/reviews/demotime/review/5/rev/1/">Paused Demo</a>, that you're following is now paused.</p>\n\n\n\n	12	5	1	\N	"Paused Demo" has been Paused	19
42	2017-01-09 00:41:17.169975+00	2017-01-09 00:41:17.170048+00	\n\n\n\n<p>\n    You have been added as a owner on <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/">Open and Active Demo</a>!\n</p>\n\n\n\n	8	6	1	\N	You have been added as an owner of Open and Active Demo	20
43	2017-01-09 00:41:17.803613+00	2017-01-09 00:41:17.803702+00	\n\n\n\n<p>\n\n    \n        A new demo has been created and assigned to you: <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/">Open and Active Demo</a>.\n    \n\n</p>\n\n\n\n	7	6	1	\N	New Review: Open and Active Demo	21
44	2017-01-09 00:41:17.873982+00	2017-01-09 00:41:17.874021+00	\n\n\n\n<p>\n\n    \n        A new demo has been created and assigned to you: <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/">Open and Active Demo</a>.\n    \n\n</p>\n\n\n\n	18	6	1	\N	New Review: Open and Active Demo	22
45	2017-01-09 00:41:17.93862+00	2017-01-09 00:41:17.939004+00	\n\n\n\n<p>\n\n    \n        A new demo has been created and assigned to you: <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/">Open and Active Demo</a>.\n    \n\n</p>\n\n\n\n	6	6	1	\N	New Review: Open and Active Demo	23
46	2017-01-09 00:41:18.014073+00	2017-01-09 00:41:18.014115+00	\n\n\n\n<p>\n\n    \n        You have been assigned as a follower on <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/">Open and Active Demo</a>.\n    \n\n</p>\n\n\n\n	10	6	1	\N	New Review: Open and Active Demo	24
47	2017-01-09 00:41:18.09028+00	2017-01-09 00:41:18.09032+00	\n\n\n\n<p>\n\n    \n        You have been assigned as a follower on <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/">Open and Active Demo</a>.\n    \n\n</p>\n\n\n\n	13	6	1	\N	New Review: Open and Active Demo	25
48	2017-01-09 00:41:36.999132+00	2017-01-09 00:41:36.999169+00	\n\n\n\n<p>\nLeo Stahl has rejected your demo, <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/">Open and Active Demo</a>.\n</p>\n\n\n\n	8	6	1	\N	Leo Stahl has rejected your review: Open and Active Demo	20
49	2017-01-09 00:41:37.056541+00	2017-01-09 00:41:37.056584+00	\n\n\n\n<p>\nLeo Stahl has rejected your demo, <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/">Open and Active Demo</a>.\n</p>\n\n\n\n	2	6	1	\N	Leo Stahl has rejected your review: Open and Active Demo	26
50	2017-01-09 00:42:01.828049+00	2017-01-09 00:42:01.828085+00	\n\n\n\n<p>\nLeo Stahl just added a new comment to <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/#5">Open and Active Demo</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        I have issues with this demo\n    </blockquote>\n    \n\n\n\n\n\n	18	6	1	4	New Comment on Open and Active Demo	22
51	2017-01-09 00:42:01.895638+00	2017-01-09 00:42:01.89571+00	\n\n\n\n<p>\nLeo Stahl just added a new comment to <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/#5">Open and Active Demo</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        I have issues with this demo\n    </blockquote>\n    \n\n\n\n\n\n	7	6	1	4	New Comment on Open and Active Demo	21
52	2017-01-09 00:42:01.966885+00	2017-01-09 00:42:01.966919+00	\n\n\n\n<p>\nLeo Stahl just added a new comment to <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/#5">Open and Active Demo</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        I have issues with this demo\n    </blockquote>\n    \n\n\n\n\n\n	13	6	1	4	New Comment on Open and Active Demo	25
53	2017-01-09 00:42:02.048276+00	2017-01-09 00:42:02.048312+00	\n\n\n\n<p>\nLeo Stahl just added a new comment to <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/#5">Open and Active Demo</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        I have issues with this demo\n    </blockquote>\n    \n\n\n\n\n\n	2	6	1	4	New Comment on Open and Active Demo	26
54	2017-01-09 00:42:02.121376+00	2017-01-09 00:42:02.121413+00	\n\n\n\n<p>\nLeo Stahl just added a new comment to <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/#5">Open and Active Demo</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        I have issues with this demo\n    </blockquote>\n    \n\n\n\n\n\n	10	6	1	4	New Comment on Open and Active Demo	24
55	2017-01-09 00:42:02.197283+00	2017-01-09 00:42:02.197321+00	\n\n\n\n<p>\nLeo Stahl just added a new comment to <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/#5">Open and Active Demo</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        I have issues with this demo\n    </blockquote>\n    \n\n\n\n\n\n	8	6	1	4	New Comment on Open and Active Demo	20
56	2017-01-09 00:42:27.066816+00	2017-01-09 00:42:27.066875+00	\n\n\n\n<p>\nLucy West just added a new comment to <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/#6">Open and Active Demo</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        I'm pretty cool with this.\n    </blockquote>\n    \n\n\n\n\n\n	18	6	1	5	New Comment on Open and Active Demo	22
57	2017-01-09 00:42:27.142245+00	2017-01-09 00:42:27.142311+00	\n\n\n\n<p>\nLucy West just added a new comment to <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/#6">Open and Active Demo</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        I'm pretty cool with this.\n    </blockquote>\n    \n\n\n\n\n\n	13	6	1	5	New Comment on Open and Active Demo	25
58	2017-01-09 00:42:27.271067+00	2017-01-09 00:42:27.271104+00	\n\n\n\n<p>\nLucy West just added a new comment to <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/#6">Open and Active Demo</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        I'm pretty cool with this.\n    </blockquote>\n    \n\n\n\n\n\n	6	6	1	5	New Comment on Open and Active Demo	23
59	2017-01-09 00:42:27.351088+00	2017-01-09 00:42:27.351171+00	\n\n\n\n<p>\nLucy West just added a new comment to <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/#6">Open and Active Demo</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        I'm pretty cool with this.\n    </blockquote>\n    \n\n\n\n\n\n	2	6	1	5	New Comment on Open and Active Demo	26
60	2017-01-09 00:42:27.443957+00	2017-01-09 00:42:27.443993+00	\n\n\n\n<p>\nLucy West just added a new comment to <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/#6">Open and Active Demo</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        I'm pretty cool with this.\n    </blockquote>\n    \n\n\n\n\n\n	10	6	1	5	New Comment on Open and Active Demo	24
61	2017-01-09 00:42:27.522959+00	2017-01-09 00:42:27.522997+00	\n\n\n\n<p>\nLucy West just added a new comment to <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/#6">Open and Active Demo</a>\n</p>\n\n    <blockquote style="background: #fff; border: 1px solid #eee; margin: 0; padding: 15px;">\n        I'm pretty cool with this.\n    </blockquote>\n    \n\n\n\n\n\n	8	6	1	5	New Comment on Open and Active Demo	20
62	2017-01-09 00:42:32.70336+00	2017-01-09 00:42:32.703412+00	\n\n\n\n<p>\nLucy West has approved your demo, <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/">Open and Active Demo</a>.\n</p>\n\n\n\n	8	6	1	\N	Lucy West has approved your review: Open and Active Demo	20
63	2017-01-09 00:42:32.833865+00	2017-01-09 00:42:32.833909+00	\n\n\n\n<p>\nLucy West has approved your demo, <a href="http://local.demotime.com:8033/reviews/demotime/review/6/rev/1/">Open and Active Demo</a>.\n</p>\n\n\n\n	2	6	1	\N	Lucy West has approved your review: Open and Active Demo	26
\.


--
-- Name: demotime_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_message_id_seq', 63, true);


--
-- Data for Name: demotime_messagebundle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_messagebundle (id, created, modified, read, deleted, owner_id, review_id) FROM stdin;
9	2016-10-16 20:33:31.812285+00	2016-10-16 20:33:31.812442+00	f	f	6	2
10	2016-10-16 20:34:03.050319+00	2016-10-16 20:34:03.050351+00	t	f	2	2
8	2016-10-16 20:33:31.627795+00	2016-10-16 20:34:44.801872+00	f	f	8	2
12	2016-10-16 20:35:31.387334+00	2016-10-16 20:35:31.38737+00	f	f	11	3
11	2016-10-16 20:35:31.235577+00	2016-10-16 20:36:54.389663+00	f	f	8	3
13	2016-10-16 20:35:42.916108+00	2016-10-16 20:36:44.982945+00	t	f	2	3
14	2017-01-09 04:42:22.132875+00	2017-01-09 04:42:22.132912+00	f	f	8	4
15	2017-01-09 04:43:01.774317+00	2017-01-09 04:43:01.774375+00	f	f	8	5
16	2017-01-09 04:43:02.371643+00	2017-01-09 04:43:02.371676+00	f	f	7	5
17	2017-01-09 04:43:02.444948+00	2017-01-09 04:43:02.444987+00	f	f	18	5
18	2017-01-09 04:43:02.518156+00	2017-01-09 04:43:02.5182+00	f	f	11	5
19	2017-01-09 04:43:02.589935+00	2017-01-09 04:43:02.589971+00	f	f	12	5
20	2017-01-09 00:41:17.156001+00	2017-01-09 00:41:17.15604+00	f	f	8	6
22	2017-01-09 00:41:17.860128+00	2017-01-09 00:41:17.860174+00	f	f	18	6
24	2017-01-09 00:41:18.001073+00	2017-01-09 00:41:18.001113+00	f	f	10	6
25	2017-01-09 00:41:18.074379+00	2017-01-09 00:41:18.074414+00	f	f	13	6
26	2017-01-09 00:41:37.044409+00	2017-01-09 00:41:37.044443+00	f	f	2	6
23	2017-01-09 00:41:17.924334+00	2017-01-09 00:42:27.245922+00	f	f	6	6
21	2017-01-09 00:41:17.787519+00	2017-01-09 00:41:17.787553+00	t	f	7	6
\.


--
-- Name: demotime_messagebundle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_messagebundle_id_seq', 26, true);


--
-- Data for Name: demotime_project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_project (id, created, modified, name, slug, description, is_public, token) FROM stdin;
1	2016-10-16 19:48:26.526386+00	2016-10-16 19:48:26.526442+00	Default Project	default-project	Default DemoTime Project	f	192fe35e088e44dea791c17b4b49cda7
2	2016-10-16 19:51:43.859528+00	2016-10-16 19:56:49.222078+00	Domestique Studios	domestique-studios	Domestique Studios	f	
3	2016-10-16 19:52:02.264882+00	2016-10-16 19:57:19.774765+00	DemoTime	demotime	DemoTime	f	
\.


--
-- Name: demotime_project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_project_id_seq', 3, true);


--
-- Data for Name: demotime_projectgroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_projectgroup (id, created, modified, is_admin, group_id, project_id) FROM stdin;
1	2016-10-16 19:48:26.533061+00	2016-10-16 19:48:26.533103+00	t	1	1
2	2016-10-16 19:56:49.258055+00	2016-10-16 19:56:49.258086+00	t	4	2
3	2016-10-16 19:56:49.272187+00	2016-10-16 19:56:49.272222+00	t	3	2
4	2016-10-16 19:56:49.286491+00	2016-10-16 19:56:49.286528+00	t	2	2
5	2016-10-16 19:57:19.804875+00	2016-10-16 19:57:19.804908+00	t	4	3
6	2016-10-16 19:57:19.820987+00	2016-10-16 19:57:19.821037+00	t	3	3
7	2016-10-16 19:57:19.837216+00	2016-10-16 19:57:19.837309+00	t	2	3
\.


--
-- Name: demotime_projectgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_projectgroup_id_seq', 7, true);


--
-- Data for Name: demotime_projectmember; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_projectmember (id, created, modified, is_admin, project_id, user_id) FROM stdin;
2	2016-10-16 19:52:41.044649+00	2016-10-16 19:56:49.240349+00	t	2	2
1	2016-10-16 19:52:27.738798+00	2016-10-16 19:57:19.791563+00	t	3	2
\.


--
-- Name: demotime_projectmember_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_projectmember_id_seq', 2, true);


--
-- Data for Name: demotime_reminder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_reminder (id, created, modified, reminder_type, remind_at, active, review_id, user_id) FROM stdin;
6	2016-10-16 20:33:31.88987+00	2016-10-16 20:33:31.889915+00	reviewer	2016-10-18 20:33:31.889346+00	f	2	8
5	2016-10-16 20:33:31.863567+00	2016-10-16 20:33:31.863619+00	creator	2016-10-18 20:33:31.86272+00	f	2	2
8	2016-10-16 20:35:31.453927+00	2016-10-16 20:35:31.453956+00	reviewer	2016-10-18 20:35:31.453562+00	f	3	8
7	2016-10-16 20:35:31.433961+00	2016-10-16 20:35:31.434013+00	creator	2016-10-18 20:35:31.433197+00	f	3	2
9	2017-01-09 04:43:02.639646+00	2017-01-09 04:43:02.682801+00	creator	2017-01-11 04:43:02.63729+00	f	5	8
10	2017-01-09 04:43:02.707754+00	2017-01-09 04:43:02.723278+00	creator	2017-01-11 04:43:02.706046+00	f	5	2
11	2017-01-09 04:43:02.743171+00	2017-01-09 04:43:02.755917+00	reviewer	2017-01-11 04:43:02.740878+00	f	5	7
12	2017-01-09 04:43:02.775639+00	2017-01-09 04:43:02.788856+00	reviewer	2017-01-11 04:43:02.77376+00	f	5	18
13	2017-01-09 00:41:18.132141+00	2017-01-09 00:41:18.144245+00	creator	2017-01-11 00:41:18.128995+00	t	6	8
14	2017-01-09 00:41:18.161525+00	2017-01-09 00:41:18.1751+00	creator	2017-01-11 00:41:18.159705+00	t	6	2
16	2017-01-09 00:41:18.227909+00	2017-01-09 00:41:18.240082+00	reviewer	2017-01-11 00:41:18.226193+00	t	6	18
17	2017-01-09 00:41:18.261474+00	2017-01-09 00:41:18.273856+00	reviewer	2017-01-11 00:41:18.259732+00	f	6	6
15	2017-01-09 00:41:18.195302+00	2017-01-09 00:41:18.210036+00	reviewer	2017-01-11 00:41:18.193614+00	f	6	7
\.


--
-- Name: demotime_reminder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_reminder_id_seq', 17, true);


--
-- Data for Name: demotime_review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_review (id, created, modified, title, description, case_link, state, reviewer_state, is_public, project_id, last_action_by_id) FROM stdin;
3	2016-10-16 20:35:30.936967+00	2016-10-16 20:36:54.275607+00	Test Demo 2	This is the second Test Demo!	Test Demo 2	closed	approved	f	2	2
2	2016-10-16 20:33:31.309686+00	2016-10-16 20:34:57.217938+00	Test Demo 1	This is test demo 1	Test Demo 1	closed	approved	f	3	2
4	2017-01-09 04:42:21.971905+00	2017-01-09 04:42:21.971956+00	Draft Demo	This demo is a draft	draft-demo	draft	reviewing	f	3	2
5	2017-01-09 04:43:02.807016+00	2017-01-09 04:43:05.502218+00	Paused Demo	This is a paused demo	paused-demo	paused	reviewing	f	3	2
6	2017-01-09 00:41:18.286183+00	2017-01-09 00:41:18.286496+00	Open and Active Demo	This is an open and active demo	open-active-demo	open	reviewing	f	3	2
\.


--
-- Name: demotime_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_review_id_seq', 6, true);


--
-- Data for Name: demotime_reviewer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_reviewer (id, created, modified, status, review_id, reviewer_id, is_active) FROM stdin;
4	2016-10-16 20:33:31.358658+00	2016-10-16 20:34:02.952415+00	approved	2	8	t
5	2016-10-16 20:35:31.008617+00	2016-10-16 20:35:42.820134+00	approved	3	8	t
6	2017-01-09 04:42:22.309195+00	2017-01-09 04:42:22.325149+00	reviewing	4	6	t
7	2017-01-09 04:42:22.369558+00	2017-01-09 04:42:22.381994+00	reviewing	4	18	t
8	2017-01-09 04:43:02.819092+00	2017-01-09 04:43:02.819131+00	reviewing	5	18	t
9	2017-01-09 04:43:02.819092+00	2017-01-09 04:43:02.819131+00	reviewing	5	7	t
11	2017-01-09 00:41:18.300265+00	2017-01-09 00:41:18.300314+00	reviewing	6	18	t
10	2017-01-09 00:41:18.300265+00	2017-01-09 00:41:36.927484+00	rejected	6	6	t
12	2017-01-09 00:41:18.300265+00	2017-01-09 00:42:32.573071+00	approved	6	7	t
\.


--
-- Name: demotime_reviewer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_reviewer_id_seq', 12, true);


--
-- Data for Name: demotime_reviewrevision; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_reviewrevision (id, created, modified, description, review_id, number) FROM stdin;
2	2016-10-16 20:33:31.326173+00	2016-10-16 20:33:31.326238+00	This is test demo 1	2	1
3	2016-10-16 20:35:30.954942+00	2016-10-16 20:35:30.95501+00	This is the second Test Demo!	3	1
4	2017-01-09 04:42:21.99213+00	2017-01-09 04:42:21.992188+00	This demo is a draft	4	1
5	2017-01-09 04:43:01.656958+00	2017-01-09 04:43:01.656995+00	This is a paused demo	5	1
6	2017-01-09 00:41:17.06154+00	2017-01-09 00:41:17.061623+00	This is an open and active demo	6	1
\.


--
-- Name: demotime_reviewrevision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_reviewrevision_id_seq', 6, true);


--
-- Data for Name: demotime_setting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_setting (id, created, modified, title, key, description, raw_value, setting_type, active, project_id) FROM stdin;
1	2016-10-16 19:48:27.910183+00	2016-10-16 19:48:27.910238+00	Emojis Enabled	emojis_enabled	When enabled, users will be able to add emojis to their Demos	true	bool	t	\N
2	2016-10-16 19:48:27.913551+00	2016-10-16 19:48:27.913586+00	Gif Embedding Enabled	gifs_enabled	When enabled, users will be able to embed gifs from Giphy	true	bool	t	\N
3	2016-10-16 19:48:27.914728+00	2016-10-16 19:48:27.91476+00	Reminder Days	reminder_days	Number of days before a Reminder is sent	2	int	t	\N
4	2016-10-16 19:48:27.918442+00	2016-10-16 19:48:27.918475+00	Reminder Days	reminder_days	Number of days before a Reminder is sent	2	int	t	1
5	2016-10-16 19:48:27.919417+00	2016-10-16 19:48:27.919446+00	Gif Embedding Enabled	gifs_enabled	When enabled, users will be able to embed gifs from Giphy	true	bool	t	1
6	2016-10-16 19:48:27.92024+00	2016-10-16 19:48:27.920269+00	Emojis Enabled	emojis_enabled	When enabled, users will be able to add emojis to their Demos	true	bool	t	1
7	2016-10-16 19:51:43.882522+00	2016-10-16 19:51:43.882554+00	Emojis Enabled	emojis_enabled	When enabled, users will be able to add emojis to their Demos	true	bool	t	2
8	2016-10-16 19:51:43.90372+00	2016-10-16 19:51:43.903758+00	Gif Embedding Enabled	gifs_enabled	When enabled, users will be able to embed gifs from Giphy	true	bool	t	2
9	2016-10-16 19:51:43.918747+00	2016-10-16 19:51:43.918789+00	Reminder Days	reminder_days	Number of days before a Reminder is sent	2	int	t	2
10	2016-10-16 19:52:02.281085+00	2016-10-16 19:52:02.281117+00	Emojis Enabled	emojis_enabled	When enabled, users will be able to add emojis to their Demos	true	bool	t	3
11	2016-10-16 19:52:02.30443+00	2016-10-16 19:52:02.304464+00	Gif Embedding Enabled	gifs_enabled	When enabled, users will be able to embed gifs from Giphy	true	bool	t	3
12	2016-10-16 19:52:02.315981+00	2016-10-16 19:52:02.316048+00	Reminder Days	reminder_days	Number of days before a Reminder is sent	2	int	t	3
\.


--
-- Name: demotime_setting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_setting_id_seq', 12, true);


--
-- Data for Name: demotime_userprofile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_userprofile (id, created, modified, avatar, bio, display_name, user_id, user_type) FROM stdin;
1	2016-10-16 19:48:23.78643+00	2016-10-16 19:48:24.244376+00			\N	1	system
2	2016-10-16 19:50:00.197886+00	2016-10-16 19:51:13.272154+00	users/2/laughing_lizard.jpg	I'm the admin	Admin	2	user
5	2016-10-16 20:18:06.892985+00	2016-10-16 20:21:27.641764+00		Moira Brown	Moira Brown	4	user
6	2016-10-16 20:18:06.980626+00	2016-10-16 20:21:27.672895+00		Moriarty Senior	Moriarty Senior	5	user
7	2016-10-16 20:18:07.056394+00	2016-10-16 20:21:27.694558+00		Leo Stahl	Leo Stahl	6	user
8	2016-10-16 20:18:07.137238+00	2016-10-16 20:21:27.71541+00		Lucy West	Lucy West	7	user
9	2016-10-16 20:18:07.212873+00	2016-10-16 20:21:27.740949+00		Billy Creel	Billy Creel	8	user
15	2016-10-16 20:18:07.684135+00	2016-10-16 20:21:27.755266+00		Manya Vargas	Manya Vargas	14	user
16	2016-10-16 20:18:07.764934+00	2016-10-16 20:21:27.772267+00		Colin Moriarty	Colin Moriarty	15	user
17	2016-10-16 20:18:07.844758+00	2016-10-16 20:21:27.787366+00		Rosa Meitner	Rosa Meitner	16	user
18	2016-10-16 20:18:07.929219+00	2016-10-16 20:21:27.803045+00		Nathaniel Vargas	Nathaniel Vargas	17	user
19	2016-10-16 20:18:08.006692+00	2016-10-16 20:21:27.820888+00		Lucas Simms	Lucas Simms	18	user
10	2016-10-16 20:18:07.285676+00	2016-10-16 20:21:27.837915+00		Madison Li	Madison Li	9	user
11	2016-10-16 20:18:07.3635+00	2016-10-16 20:21:27.855577+00		Seagrave Holmes	Seagrave Holmes	10	user
12	2016-10-16 20:18:07.440353+00	2016-10-16 20:21:27.870952+00		Christie Young	Christie Young	11	user
13	2016-10-16 20:18:07.518486+00	2016-10-16 20:21:27.885571+00		Cindy Cantelli	Cindy Cantelli	12	user
14	2016-10-16 20:18:07.606345+00	2016-10-16 20:21:27.900379+00		Ted Strayer	Ted Strayer	13	user
\.


--
-- Name: demotime_userprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_userprofile_id_seq', 19, true);


--
-- Data for Name: demotime_userreviewstatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_userreviewstatus (id, created, modified, read, review_id, user_id) FROM stdin;
10	2016-10-16 20:33:31.489242+00	2016-10-16 20:33:31.501037+00	t	2	2
8	2016-10-16 20:33:31.392573+00	2016-10-16 20:33:31.405573+00	f	2	8
9	2016-10-16 20:33:31.456275+00	2016-10-16 20:33:31.471246+00	f	2	6
11	2016-10-16 20:35:31.05794+00	2016-10-16 20:35:31.071379+00	f	3	8
12	2016-10-16 20:35:31.142325+00	2016-10-16 20:35:31.159921+00	f	3	11
13	2016-10-16 20:35:31.178013+00	2016-10-16 20:35:31.195302+00	t	3	2
14	2017-01-09 04:42:22.247621+00	2017-01-09 04:42:22.294533+00	f	4	8
15	2017-01-09 04:42:22.338785+00	2017-01-09 04:42:22.352937+00	f	4	6
16	2017-01-09 04:42:22.395261+00	2017-01-09 04:42:22.407225+00	f	4	18
17	2017-01-09 04:42:22.453431+00	2017-01-09 04:42:22.466734+00	f	4	11
18	2017-01-09 04:42:22.538529+00	2017-01-09 04:42:22.55113+00	f	4	12
19	2017-01-09 04:42:22.565787+00	2017-01-09 04:42:22.578564+00	t	4	2
20	2017-01-09 04:43:01.837846+00	2017-01-09 04:43:01.915514+00	f	5	8
21	2017-01-09 04:43:02.022269+00	2017-01-09 04:43:02.035993+00	f	5	18
22	2017-01-09 04:43:02.103003+00	2017-01-09 04:43:02.121147+00	f	5	7
23	2017-01-09 04:43:02.169155+00	2017-01-09 04:43:02.181674+00	f	5	11
24	2017-01-09 04:43:02.23222+00	2017-01-09 04:43:02.248101+00	f	5	12
25	2017-01-09 04:43:02.266316+00	2017-01-09 04:43:02.334225+00	t	5	2
28	2017-01-09 00:41:17.458749+00	2017-01-09 00:41:17.470605+00	f	6	18
31	2017-01-09 00:41:17.661345+00	2017-01-09 00:41:17.673725+00	f	6	13
27	2017-01-09 00:41:17.395939+00	2017-01-09 00:41:17.409978+00	f	6	6
32	2017-01-09 00:41:17.691281+00	2017-01-09 00:41:17.748627+00	f	6	2
30	2017-01-09 00:41:17.595892+00	2017-01-09 00:41:17.608759+00	f	6	10
26	2017-01-09 00:41:17.309471+00	2017-01-09 00:41:17.349299+00	f	6	8
29	2017-01-09 00:41:17.526821+00	2017-01-09 00:41:17.544619+00	t	6	7
\.


--
-- Name: demotime_userreviewstatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_userreviewstatus_id_seq', 32, true);


--
-- Data for Name: demotime_webhook; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY demotime_webhook (id, created, modified, target, trigger_event, project_id) FROM stdin;
\.


--
-- Name: demotime_webhook_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('demotime_webhook_id_seq', 1, false);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 1, false);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_content_type (id, app_label, model) FROM stdin;
1	demotime	project
2	demotime	groupmember
3	demotime	commentthread
4	demotime	message
5	demotime	webhook
6	demotime	review
7	demotime	grouptype
8	demotime	userprofile
9	demotime	projectgroup
10	demotime	attachment
11	demotime	group
12	demotime	comment
13	demotime	userreviewstatus
14	demotime	setting
15	demotime	reviewrevision
16	demotime	follower
17	demotime	reviewer
18	demotime	reminder
19	demotime	projectmember
20	demotime	userproxy
21	demotime	messagebundle
22	admin	logentry
23	auth	permission
24	auth	group
25	auth	user
26	contenttypes	contenttype
27	sessions	session
28	sites	site
29	demotime	eventtype
30	demotime	event
31	registration	registrationprofile
32	demotime	issue
33	demotime	creator
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_content_type_id_seq', 33, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2016-10-16 19:48:20.115334+00
2	auth	0001_initial	2016-10-16 19:48:20.744947+00
3	admin	0001_initial	2016-10-16 19:48:20.906372+00
4	admin	0002_logentry_remove_auto_add	2016-10-16 19:48:20.952772+00
5	contenttypes	0002_remove_content_type_name	2016-10-16 19:48:21.007218+00
6	auth	0002_alter_permission_name_max_length	2016-10-16 19:48:21.047582+00
7	auth	0003_alter_user_email_max_length	2016-10-16 19:48:21.089362+00
8	auth	0004_alter_user_username_opts	2016-10-16 19:48:21.119578+00
9	auth	0005_alter_user_last_login_null	2016-10-16 19:48:21.161168+00
10	auth	0006_require_contenttypes_0002	2016-10-16 19:48:21.177781+00
11	auth	0007_alter_validators_add_error_messages	2016-10-16 19:48:21.205115+00
12	demotime	0001_initial	2016-10-16 19:48:21.911633+00
13	demotime	0002_auto_20150323_0228	2016-10-16 19:48:21.999672+00
14	demotime	0003_auto_20150324_0144	2016-10-16 19:48:22.236341+00
15	demotime	0004_auto_20150329_1740	2016-10-16 19:48:22.291311+00
16	demotime	0005_auto_20150404_2216	2016-10-16 19:48:22.827007+00
17	demotime	0006_auto_20150404_2220	2016-10-16 19:48:22.854547+00
18	demotime	0007_message_title	2016-10-16 19:48:23.056096+00
19	demotime	0008_auto_20150407_0143	2016-10-16 19:48:23.320952+00
20	demotime	0009_attachment_description	2016-10-16 19:48:23.391299+00
21	demotime	0010_auto_20150410_0026	2016-10-16 19:48:23.614524+00
22	demotime	0011_auto_20150412_2037	2016-10-16 19:48:23.766379+00
23	demotime	0012_auto_20150412_2039	2016-10-16 19:48:23.802376+00
24	demotime	0013_auto_20150414_0126	2016-10-16 19:48:23.901178+00
25	demotime	0014_userreviewstatus	2016-10-16 19:48:24.039229+00
26	demotime	0015_userprofile_user_type	2016-10-16 19:48:24.264445+00
27	demotime	0016_auto_20150503_1952	2016-10-16 19:48:24.513022+00
28	demotime	0017_auto_20160326_1724	2016-10-16 19:48:24.581687+00
29	demotime	0018_auto_20160326_1940	2016-10-16 19:48:24.655375+00
30	demotime	0019_auto_20160327_1902	2016-10-16 19:48:24.701054+00
31	demotime	0020_rename_photo_attachment_type	2016-10-16 19:48:24.742817+00
32	demotime	0021_messagebundle	2016-10-16 19:48:24.931534+00
33	demotime	0022_migrate_bundles	2016-10-16 19:48:24.952139+00
34	demotime	0023_auto_20160401_0153	2016-10-16 19:48:25.104477+00
35	demotime	0024_auto_20160409_2059	2016-10-16 19:48:25.298636+00
36	demotime	0025_review_followers	2016-10-16 19:48:25.336477+00
37	demotime	0024_auto_20160412_2305	2016-10-16 19:48:25.37808+00
38	demotime	0026_merge	2016-10-16 19:48:25.396574+00
39	demotime	0027_auto_20160424_2224	2016-10-16 19:48:26.512724+00
40	demotime	0028_create_projects_groups_group_types	2016-10-16 19:48:26.551103+00
41	demotime	0029_auto_20160424_2233	2016-10-16 19:48:26.68613+00
42	demotime	0030_auto_20160701_1539	2016-10-16 19:48:27.413558+00
43	demotime	0031_generate_project_tokens	2016-10-16 19:48:27.446105+00
44	demotime	0032_auto_20160702_1414	2016-10-16 19:48:27.54635+00
45	demotime	0033_auto_20160717_1651	2016-10-16 19:48:27.603887+00
46	demotime	0034_setting	2016-10-16 19:48:27.892625+00
47	demotime	0035_create_settings	2016-10-16 19:48:27.936681+00
48	demotime	0036_auto_20160813_1448	2016-10-16 19:48:28.164712+00
49	demotime	0037_auto_20160823_1755	2016-10-16 19:48:28.399753+00
50	demotime	0038_set_attachment_sort_order	2016-10-16 19:48:28.440586+00
51	demotime	0037_auto_20160824_1933	2016-10-16 19:48:28.929906+00
52	demotime	0038_add_event_types	2016-10-16 19:48:28.993952+00
53	demotime	0039_merge	2016-10-16 19:48:29.013739+00
54	demotime	0040_auto_20160904_1630	2016-10-16 19:48:29.370557+00
55	demotime	0041_auto_20160923_2046	2016-10-16 19:48:29.471025+00
56	registration	0001_initial	2016-10-16 19:48:29.608516+00
57	registration	0002_registrationprofile_activated	2016-10-16 19:48:29.765008+00
58	registration	0003_migrate_activatedstatus	2016-10-16 19:48:29.78795+00
59	sessions	0001_initial	2016-10-16 19:48:29.942224+00
60	sites	0001_initial	2016-10-16 19:48:30.001215+00
61	sites	0002_alter_domain_unique	2016-10-16 19:48:30.088747+00
62	auth	0008_alter_user_username_max_length	2017-01-08 22:10:48.262885+00
63	demotime	0042_auto_20161030_1437	2017-01-08 22:10:48.821404+00
64	demotime	0042_auto_20161030_1412	2017-01-08 22:10:48.983622+00
65	demotime	0043_merge	2017-01-08 22:10:49.006071+00
66	demotime	0044_auto_20161126_1537	2017-01-08 22:10:49.294692+00
67	demotime	0045_add_pause_event_type	2017-01-08 22:10:49.329897+00
68	demotime	0046_auto_20161203_1605	2017-01-08 22:10:50.122793+00
69	demotime	0047_migrate_creators	2017-01-08 22:10:50.2275+00
70	demotime	0048_remove_review_creator	2017-01-08 22:10:50.378506+00
71	demotime	0049_auto_20161211_1620	2017-01-08 22:10:50.444665+00
72	demotime	0050_auto_20161229_2057	2017-01-08 22:10:50.833237+00
73	demotime	0051_add_issue_event_types	2017-01-08 22:10:50.877989+00
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_migrations_id_seq', 73, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
3r0q2vo032cvif7h4ib8z43r2rtlxfsb	YmFmODE4ZTljZTZkZWRkOWU5YzE4Yzk1ZDQ0YzY5YzljNWI3OTU2NTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRlbW90aW1lLmF1dGhlbnRpY2F0aW9uX2JhY2tlbmRzLlVzZXJQcm94eU1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6IjJiMjhjZTEzN2ZhYzBmMDRkYTM0ODY5ZjY4NWIyN2U0NGM0YzVhYTgiLCJfYXV0aF91c2VyX2lkIjoiMiJ9	2016-10-30 19:50:14.674715+00
wjbsk105m3rj370wg2m8f1jcqwkwgxg0	ZjJlNzU5ZTM1ZTM5ZmE1Nzk1NDM1ZDZmYWE0M2U0NzhmZjBiOGRmMDp7Il9hdXRoX3VzZXJfaWQiOiI4IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGVtb3RpbWUuYXV0aGVudGljYXRpb25fYmFja2VuZHMuVXNlclByb3h5TW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYzdjYTJlMmI5MTVjMzMwNWM5ZWQ3NTgzOTg3NWI3YzE0NTllOGM0NCJ9	2016-10-30 20:33:58.269283+00
fobuvre0pfk9gz7bymsomuss7opy3bmz	OGFkYjdiODBkYTVlOWRjMDk5ZDA0YmIzMGEyOTVkNTNkYjFjNjE1ODp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRlbW90aW1lLmF1dGhlbnRpY2F0aW9uX2JhY2tlbmRzLlVzZXJQcm94eU1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9oYXNoIjoiMjExZWI5YWRlMjM1ZTQ3ZjZmM2Y5YWIxMThlYzkyMGM2YmU3OWYyNSJ9	2017-01-23 02:50:30.083236+00
90bxu3btvodmvl2gvlb0vezweojookcs	OWI5ODgxOGJkYjBlZjBmMTE4MDUyOWYxOTFlOWI3ODBhYjRlODg5NTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRlbW90aW1lLmF1dGhlbnRpY2F0aW9uX2JhY2tlbmRzLlVzZXJQcm94eU1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI3IiwiX2F1dGhfdXNlcl9oYXNoIjoiNTQwMWVmMDU2NjlmZmI5MzVmOWVlZjRhYTNjYTQ5ZDhhOTJkMzcyZCJ9	2017-01-23 00:42:14.231211+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_site (id, domain, name) FROM stdin;
1	example.com	example.com
\.


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_site_id_seq', 1, true);


--
-- Data for Name: registration_registrationprofile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY registration_registrationprofile (id, activation_key, user_id, activated) FROM stdin;
\.


--
-- Name: registration_registrationprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('registration_registrationprofile_id_seq', 1, false);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: demotime_attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_attachment
    ADD CONSTRAINT demotime_attachment_pkey PRIMARY KEY (id);


--
-- Name: demotime_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_comment
    ADD CONSTRAINT demotime_comment_pkey PRIMARY KEY (id);


--
-- Name: demotime_commentthread_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_commentthread
    ADD CONSTRAINT demotime_commentthread_pkey PRIMARY KEY (id);


--
-- Name: demotime_creator_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_creator
    ADD CONSTRAINT demotime_creator_pkey PRIMARY KEY (id);


--
-- Name: demotime_event_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_event
    ADD CONSTRAINT demotime_event_pkey PRIMARY KEY (id);


--
-- Name: demotime_eventtype_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_eventtype
    ADD CONSTRAINT demotime_eventtype_code_key UNIQUE (code);


--
-- Name: demotime_eventtype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_eventtype
    ADD CONSTRAINT demotime_eventtype_pkey PRIMARY KEY (id);


--
-- Name: demotime_follower_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_follower
    ADD CONSTRAINT demotime_follower_pkey PRIMARY KEY (id);


--
-- Name: demotime_follower_review_id_d83aff48_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_follower
    ADD CONSTRAINT demotime_follower_review_id_d83aff48_uniq UNIQUE (review_id, user_id);


--
-- Name: demotime_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_group
    ADD CONSTRAINT demotime_group_pkey PRIMARY KEY (id);


--
-- Name: demotime_group_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_group
    ADD CONSTRAINT demotime_group_slug_key UNIQUE (slug);


--
-- Name: demotime_groupmember_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_groupmember
    ADD CONSTRAINT demotime_groupmember_pkey PRIMARY KEY (id);


--
-- Name: demotime_groupmember_user_id_2ddc74fa_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_groupmember
    ADD CONSTRAINT demotime_groupmember_user_id_2ddc74fa_uniq UNIQUE (user_id, group_id);


--
-- Name: demotime_grouptype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_grouptype
    ADD CONSTRAINT demotime_grouptype_pkey PRIMARY KEY (id);


--
-- Name: demotime_grouptype_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_grouptype
    ADD CONSTRAINT demotime_grouptype_slug_key UNIQUE (slug);


--
-- Name: demotime_issue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_issue
    ADD CONSTRAINT demotime_issue_pkey PRIMARY KEY (id);


--
-- Name: demotime_message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_message
    ADD CONSTRAINT demotime_message_pkey PRIMARY KEY (id);


--
-- Name: demotime_messagebundle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_messagebundle
    ADD CONSTRAINT demotime_messagebundle_pkey PRIMARY KEY (id);


--
-- Name: demotime_project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_project
    ADD CONSTRAINT demotime_project_pkey PRIMARY KEY (id);


--
-- Name: demotime_project_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_project
    ADD CONSTRAINT demotime_project_slug_key UNIQUE (slug);


--
-- Name: demotime_projectgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_projectgroup
    ADD CONSTRAINT demotime_projectgroup_pkey PRIMARY KEY (id);


--
-- Name: demotime_projectmember_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_projectmember
    ADD CONSTRAINT demotime_projectmember_pkey PRIMARY KEY (id);


--
-- Name: demotime_reminder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_reminder
    ADD CONSTRAINT demotime_reminder_pkey PRIMARY KEY (id);


--
-- Name: demotime_reminder_review_id_cb1c7cfb_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_reminder
    ADD CONSTRAINT demotime_reminder_review_id_cb1c7cfb_uniq UNIQUE (review_id, user_id);


--
-- Name: demotime_review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_review
    ADD CONSTRAINT demotime_review_pkey PRIMARY KEY (id);


--
-- Name: demotime_reviewer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_reviewer
    ADD CONSTRAINT demotime_reviewer_pkey PRIMARY KEY (id);


--
-- Name: demotime_reviewrevision_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_reviewrevision
    ADD CONSTRAINT demotime_reviewrevision_pkey PRIMARY KEY (id);


--
-- Name: demotime_setting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_setting
    ADD CONSTRAINT demotime_setting_pkey PRIMARY KEY (id);


--
-- Name: demotime_userprofile_display_name_fd50f53d_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_userprofile
    ADD CONSTRAINT demotime_userprofile_display_name_fd50f53d_uniq UNIQUE (display_name);


--
-- Name: demotime_userprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_userprofile
    ADD CONSTRAINT demotime_userprofile_pkey PRIMARY KEY (id);


--
-- Name: demotime_userprofile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_userprofile
    ADD CONSTRAINT demotime_userprofile_user_id_key UNIQUE (user_id);


--
-- Name: demotime_userreviewstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_userreviewstatus
    ADD CONSTRAINT demotime_userreviewstatus_pkey PRIMARY KEY (id);


--
-- Name: demotime_webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_webhook
    ADD CONSTRAINT demotime_webhook_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: registration_registrationprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY registration_registrationprofile
    ADD CONSTRAINT registration_registrationprofile_pkey PRIMARY KEY (id);


--
-- Name: registration_registrationprofile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY registration_registrationprofile
    ADD CONSTRAINT registration_registrationprofile_user_id_key UNIQUE (user_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_0e939a4f ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_8373b171 ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_417f1b1c ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_0e939a4f ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_e8701ad4 ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_8373b171 ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_username_6821ab7c_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: demotime_attachment_417f1b1c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_attachment_417f1b1c ON demotime_attachment USING btree (content_type_id);


--
-- Name: demotime_attachment_content_type_id_c077cd84_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_attachment_content_type_id_c077cd84_idx ON demotime_attachment USING btree (content_type_id, object_id);


--
-- Name: demotime_attachment_e480c177; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_attachment_e480c177 ON demotime_attachment USING btree (attachment_type);


--
-- Name: demotime_comment_d819cf18; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_comment_d819cf18 ON demotime_comment USING btree (commenter_id);


--
-- Name: demotime_comment_e3464c97; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_comment_e3464c97 ON demotime_comment USING btree (thread_id);


--
-- Name: demotime_commentthread_fe5b6906; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_commentthread_fe5b6906 ON demotime_commentthread USING btree (review_revision_id);


--
-- Name: demotime_creator_5bd2a989; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_creator_5bd2a989 ON demotime_creator USING btree (review_id);


--
-- Name: demotime_creator_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_creator_e8701ad4 ON demotime_creator USING btree (user_id);


--
-- Name: demotime_event_417f1b1c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_event_417f1b1c ON demotime_event USING btree (content_type_id);


--
-- Name: demotime_event_5bd2a989; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_event_5bd2a989 ON demotime_event USING btree (review_id);


--
-- Name: demotime_event_5e891baf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_event_5e891baf ON demotime_event USING btree (event_type_id);


--
-- Name: demotime_event_b098ad43; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_event_b098ad43 ON demotime_event USING btree (project_id);


--
-- Name: demotime_event_content_type_id_58f98595_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_event_content_type_id_58f98595_idx ON demotime_event USING btree (content_type_id, object_id);


--
-- Name: demotime_event_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_event_e8701ad4 ON demotime_event USING btree (user_id);


--
-- Name: demotime_eventtype_code_8211dc11_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_eventtype_code_8211dc11_like ON demotime_eventtype USING btree (code varchar_pattern_ops);


--
-- Name: demotime_follower_4264c638; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_follower_4264c638 ON demotime_follower USING btree (is_active);


--
-- Name: demotime_follower_5bd2a989; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_follower_5bd2a989 ON demotime_follower USING btree (review_id);


--
-- Name: demotime_follower_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_follower_e8701ad4 ON demotime_follower USING btree (user_id);


--
-- Name: demotime_group_be6163f9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_group_be6163f9 ON demotime_group USING btree (group_type_id);


--
-- Name: demotime_group_slug_7789d450_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_group_slug_7789d450_like ON demotime_group USING btree (slug varchar_pattern_ops);


--
-- Name: demotime_groupmember_0e939a4f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_groupmember_0e939a4f ON demotime_groupmember USING btree (group_id);


--
-- Name: demotime_groupmember_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_groupmember_e8701ad4 ON demotime_groupmember USING btree (user_id);


--
-- Name: demotime_grouptype_slug_86e9e6a9_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_grouptype_slug_86e9e6a9_like ON demotime_grouptype USING btree (slug varchar_pattern_ops);


--
-- Name: demotime_issue_5bd2a989; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_issue_5bd2a989 ON demotime_issue USING btree (review_id);


--
-- Name: demotime_issue_62404335; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_issue_62404335 ON demotime_issue USING btree (resolved_by_id);


--
-- Name: demotime_issue_69b97d17; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_issue_69b97d17 ON demotime_issue USING btree (comment_id);


--
-- Name: demotime_issue_e93cb7eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_issue_e93cb7eb ON demotime_issue USING btree (created_by_id);


--
-- Name: demotime_issue_review_id_8ad3739f_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_issue_review_id_8ad3739f_idx ON demotime_issue USING btree (review_id, comment_id);


--
-- Name: demotime_issue_review_id_a96cbe18_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_issue_review_id_a96cbe18_idx ON demotime_issue USING btree (review_id, comment_id, resolved_by_id);


--
-- Name: demotime_message_0533a258; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_message_0533a258 ON demotime_message USING btree (bundle_id);


--
-- Name: demotime_message_29f7ae6c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_message_29f7ae6c ON demotime_message USING btree (receipient_id);


--
-- Name: demotime_message_5bd2a989; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_message_5bd2a989 ON demotime_message USING btree (review_id);


--
-- Name: demotime_message_924b1846; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_message_924b1846 ON demotime_message USING btree (sender_id);


--
-- Name: demotime_message_e3464c97; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_message_e3464c97 ON demotime_message USING btree (thread_id);


--
-- Name: demotime_messagebundle_5bd2a989; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_messagebundle_5bd2a989 ON demotime_messagebundle USING btree (review_id);


--
-- Name: demotime_messagebundle_5e7b1936; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_messagebundle_5e7b1936 ON demotime_messagebundle USING btree (owner_id);


--
-- Name: demotime_project_slug_632c62f0_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_project_slug_632c62f0_like ON demotime_project USING btree (slug varchar_pattern_ops);


--
-- Name: demotime_projectgroup_0e939a4f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_projectgroup_0e939a4f ON demotime_projectgroup USING btree (group_id);


--
-- Name: demotime_projectgroup_b098ad43; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_projectgroup_b098ad43 ON demotime_projectgroup USING btree (project_id);


--
-- Name: demotime_projectmember_b098ad43; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_projectmember_b098ad43 ON demotime_projectmember USING btree (project_id);


--
-- Name: demotime_projectmember_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_projectmember_e8701ad4 ON demotime_projectmember USING btree (user_id);


--
-- Name: demotime_reminder_5bd2a989; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_reminder_5bd2a989 ON demotime_reminder USING btree (review_id);


--
-- Name: demotime_reminder_663536e3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_reminder_663536e3 ON demotime_reminder USING btree (reminder_type);


--
-- Name: demotime_reminder_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_reminder_e8701ad4 ON demotime_reminder USING btree (user_id);


--
-- Name: demotime_reminder_reminder_type_1913755e_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_reminder_reminder_type_1913755e_like ON demotime_reminder USING btree (reminder_type varchar_pattern_ops);


--
-- Name: demotime_review_803d5711; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_review_803d5711 ON demotime_review USING btree (reviewer_state);


--
-- Name: demotime_review_9acb4454; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_review_9acb4454 ON demotime_review USING btree (state);


--
-- Name: demotime_review_b098ad43; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_review_b098ad43 ON demotime_review USING btree (project_id);


--
-- Name: demotime_review_debed301; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_review_debed301 ON demotime_review USING btree (last_action_by_id);


--
-- Name: demotime_review_status_3225fce6_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_review_status_3225fce6_like ON demotime_review USING btree (state varchar_pattern_ops);


--
-- Name: demotime_reviewer_071d8141; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_reviewer_071d8141 ON demotime_reviewer USING btree (reviewer_id);


--
-- Name: demotime_reviewer_4264c638; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_reviewer_4264c638 ON demotime_reviewer USING btree (is_active);


--
-- Name: demotime_reviewer_5bd2a989; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_reviewer_5bd2a989 ON demotime_reviewer USING btree (review_id);


--
-- Name: demotime_reviewer_9acb4454; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_reviewer_9acb4454 ON demotime_reviewer USING btree (status);


--
-- Name: demotime_reviewer_status_7bf7fdd9_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_reviewer_status_7bf7fdd9_like ON demotime_reviewer USING btree (status varchar_pattern_ops);


--
-- Name: demotime_reviewrevision_5bd2a989; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_reviewrevision_5bd2a989 ON demotime_reviewrevision USING btree (review_id);


--
-- Name: demotime_setting_3c6e0b8a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_setting_3c6e0b8a ON demotime_setting USING btree (key);


--
-- Name: demotime_setting_aba33e6b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_setting_aba33e6b ON demotime_setting USING btree (setting_type);


--
-- Name: demotime_setting_b098ad43; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_setting_b098ad43 ON demotime_setting USING btree (project_id);


--
-- Name: demotime_setting_key_92123c2f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_setting_key_92123c2f_like ON demotime_setting USING btree (key varchar_pattern_ops);


--
-- Name: demotime_setting_project_id_2f5f882d_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_setting_project_id_2f5f882d_idx ON demotime_setting USING btree (project_id, key);


--
-- Name: demotime_setting_setting_type_b8e01a4c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_setting_setting_type_b8e01a4c_like ON demotime_setting USING btree (setting_type varchar_pattern_ops);


--
-- Name: demotime_userprofile_display_name_fd50f53d_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_userprofile_display_name_fd50f53d_like ON demotime_userprofile USING btree (display_name varchar_pattern_ops);


--
-- Name: demotime_userreviewstatus_5bd2a989; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_userreviewstatus_5bd2a989 ON demotime_userreviewstatus USING btree (review_id);


--
-- Name: demotime_userreviewstatus_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_userreviewstatus_e8701ad4 ON demotime_userreviewstatus USING btree (user_id);


--
-- Name: demotime_webhook_423b06ff; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_webhook_423b06ff ON demotime_webhook USING btree (trigger_event);


--
-- Name: demotime_webhook_b098ad43; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_webhook_b098ad43 ON demotime_webhook USING btree (project_id);


--
-- Name: demotime_webhook_trigger_event_ccbc6c84_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX demotime_webhook_trigger_event_ccbc6c84_like ON demotime_webhook USING btree (trigger_event varchar_pattern_ops);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_417f1b1c ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_e8701ad4 ON django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_de54fa62 ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_site_domain_a2e37b91_like ON django_site USING btree (domain varchar_pattern_ops);


--
-- Name: auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demot_review_revision_id_567dc70e_fk_demotime_reviewrevision_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_commentthread
    ADD CONSTRAINT demot_review_revision_id_567dc70e_fk_demotime_reviewrevision_id FOREIGN KEY (review_revision_id) REFERENCES demotime_reviewrevision(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_att_content_type_id_a5d7be23_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_attachment
    ADD CONSTRAINT demotime_att_content_type_id_a5d7be23_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_commen_thread_id_e3be2f40_fk_demotime_commentthread_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_comment
    ADD CONSTRAINT demotime_commen_thread_id_e3be2f40_fk_demotime_commentthread_id FOREIGN KEY (thread_id) REFERENCES demotime_commentthread(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_comment_commenter_id_3c4c5d04_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_comment
    ADD CONSTRAINT demotime_comment_commenter_id_3c4c5d04_fk_auth_user_id FOREIGN KEY (commenter_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_creator_review_id_b6dd1632_fk_demotime_review_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_creator
    ADD CONSTRAINT demotime_creator_review_id_b6dd1632_fk_demotime_review_id FOREIGN KEY (review_id) REFERENCES demotime_review(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_creator_user_id_8fe33801_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_creator
    ADD CONSTRAINT demotime_creator_user_id_8fe33801_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_eve_content_type_id_8f02cb42_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_event
    ADD CONSTRAINT demotime_eve_content_type_id_8f02cb42_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_event_event_type_id_da73899e_fk_demotime_eventtype_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_event
    ADD CONSTRAINT demotime_event_event_type_id_da73899e_fk_demotime_eventtype_id FOREIGN KEY (event_type_id) REFERENCES demotime_eventtype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_event_project_id_99d0916a_fk_demotime_project_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_event
    ADD CONSTRAINT demotime_event_project_id_99d0916a_fk_demotime_project_id FOREIGN KEY (project_id) REFERENCES demotime_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_event_review_id_2c0d4426_fk_demotime_review_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_event
    ADD CONSTRAINT demotime_event_review_id_2c0d4426_fk_demotime_review_id FOREIGN KEY (review_id) REFERENCES demotime_review(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_event_user_id_6fb144d7_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_event
    ADD CONSTRAINT demotime_event_user_id_6fb144d7_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_follower_review_id_316ca9b9_fk_demotime_review_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_follower
    ADD CONSTRAINT demotime_follower_review_id_316ca9b9_fk_demotime_review_id FOREIGN KEY (review_id) REFERENCES demotime_review(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_follower_user_id_069a0b4a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_follower
    ADD CONSTRAINT demotime_follower_user_id_069a0b4a_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_group_group_type_id_bcdad68c_fk_demotime_grouptype_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_group
    ADD CONSTRAINT demotime_group_group_type_id_bcdad68c_fk_demotime_grouptype_id FOREIGN KEY (group_type_id) REFERENCES demotime_grouptype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_groupmember_group_id_f48c35fa_fk_demotime_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_groupmember
    ADD CONSTRAINT demotime_groupmember_group_id_f48c35fa_fk_demotime_group_id FOREIGN KEY (group_id) REFERENCES demotime_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_groupmember_user_id_46434954_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_groupmember
    ADD CONSTRAINT demotime_groupmember_user_id_46434954_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_issue_comment_id_92801ffb_fk_demotime_comment_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_issue
    ADD CONSTRAINT demotime_issue_comment_id_92801ffb_fk_demotime_comment_id FOREIGN KEY (comment_id) REFERENCES demotime_comment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_issue_created_by_id_e8ce1df5_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_issue
    ADD CONSTRAINT demotime_issue_created_by_id_e8ce1df5_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_issue_resolved_by_id_b801365e_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_issue
    ADD CONSTRAINT demotime_issue_resolved_by_id_b801365e_fk_auth_user_id FOREIGN KEY (resolved_by_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_issue_review_id_fd0fbefa_fk_demotime_review_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_issue
    ADD CONSTRAINT demotime_issue_review_id_fd0fbefa_fk_demotime_review_id FOREIGN KEY (review_id) REFERENCES demotime_review(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_messa_review_id_72304dc4_fk_demotime_reviewrevision_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_message
    ADD CONSTRAINT demotime_messa_review_id_72304dc4_fk_demotime_reviewrevision_id FOREIGN KEY (review_id) REFERENCES demotime_reviewrevision(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_messag_bundle_id_808a5739_fk_demotime_messagebundle_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_message
    ADD CONSTRAINT demotime_messag_bundle_id_808a5739_fk_demotime_messagebundle_id FOREIGN KEY (bundle_id) REFERENCES demotime_messagebundle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_messag_thread_id_136e7ff6_fk_demotime_commentthread_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_message
    ADD CONSTRAINT demotime_messag_thread_id_136e7ff6_fk_demotime_commentthread_id FOREIGN KEY (thread_id) REFERENCES demotime_commentthread(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_message_receipient_id_e5a5e0f7_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_message
    ADD CONSTRAINT demotime_message_receipient_id_e5a5e0f7_fk_auth_user_id FOREIGN KEY (receipient_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_message_sender_id_948ef12d_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_message
    ADD CONSTRAINT demotime_message_sender_id_948ef12d_fk_auth_user_id FOREIGN KEY (sender_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_messagebundle_owner_id_c264e083_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_messagebundle
    ADD CONSTRAINT demotime_messagebundle_owner_id_c264e083_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_messagebundle_review_id_b6ee826f_fk_demotime_review_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_messagebundle
    ADD CONSTRAINT demotime_messagebundle_review_id_b6ee826f_fk_demotime_review_id FOREIGN KEY (review_id) REFERENCES demotime_review(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_projectgrou_project_id_21f46a0e_fk_demotime_project_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_projectgroup
    ADD CONSTRAINT demotime_projectgrou_project_id_21f46a0e_fk_demotime_project_id FOREIGN KEY (project_id) REFERENCES demotime_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_projectgroup_group_id_e8d3aad1_fk_demotime_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_projectgroup
    ADD CONSTRAINT demotime_projectgroup_group_id_e8d3aad1_fk_demotime_group_id FOREIGN KEY (group_id) REFERENCES demotime_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_projectmemb_project_id_eb7acd87_fk_demotime_project_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_projectmember
    ADD CONSTRAINT demotime_projectmemb_project_id_eb7acd87_fk_demotime_project_id FOREIGN KEY (project_id) REFERENCES demotime_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_projectmember_user_id_5a0b3373_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_projectmember
    ADD CONSTRAINT demotime_projectmember_user_id_5a0b3373_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_reminder_review_id_044d2e6d_fk_demotime_review_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_reminder
    ADD CONSTRAINT demotime_reminder_review_id_044d2e6d_fk_demotime_review_id FOREIGN KEY (review_id) REFERENCES demotime_review(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_reminder_user_id_387e6c85_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_reminder
    ADD CONSTRAINT demotime_reminder_user_id_387e6c85_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_review_last_action_by_id_10fa3102_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_review
    ADD CONSTRAINT demotime_review_last_action_by_id_10fa3102_fk_auth_user_id FOREIGN KEY (last_action_by_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_review_project_id_512cbaf5_fk_demotime_project_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_review
    ADD CONSTRAINT demotime_review_project_id_512cbaf5_fk_demotime_project_id FOREIGN KEY (project_id) REFERENCES demotime_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_reviewer_review_id_f8e0679d_fk_demotime_review_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_reviewer
    ADD CONSTRAINT demotime_reviewer_review_id_f8e0679d_fk_demotime_review_id FOREIGN KEY (review_id) REFERENCES demotime_review(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_reviewer_reviewer_id_9f1af182_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_reviewer
    ADD CONSTRAINT demotime_reviewer_reviewer_id_9f1af182_fk_auth_user_id FOREIGN KEY (reviewer_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_reviewrevisio_review_id_ac262385_fk_demotime_review_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_reviewrevision
    ADD CONSTRAINT demotime_reviewrevisio_review_id_ac262385_fk_demotime_review_id FOREIGN KEY (review_id) REFERENCES demotime_review(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_setting_project_id_02f06faf_fk_demotime_project_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_setting
    ADD CONSTRAINT demotime_setting_project_id_02f06faf_fk_demotime_project_id FOREIGN KEY (project_id) REFERENCES demotime_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_userprofile_user_id_50ed16f4_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_userprofile
    ADD CONSTRAINT demotime_userprofile_user_id_50ed16f4_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_userreviewsta_review_id_de692dc3_fk_demotime_review_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_userreviewstatus
    ADD CONSTRAINT demotime_userreviewsta_review_id_de692dc3_fk_demotime_review_id FOREIGN KEY (review_id) REFERENCES demotime_review(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_userreviewstatus_user_id_4f5245f6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_userreviewstatus
    ADD CONSTRAINT demotime_userreviewstatus_user_id_4f5245f6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: demotime_webhook_project_id_d10c260c_fk_demotime_project_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY demotime_webhook
    ADD CONSTRAINT demotime_webhook_project_id_d10c260c_fk_demotime_project_id FOREIGN KEY (project_id) REFERENCES demotime_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_content_type_id_c4bce8eb_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_content_type_id_c4bce8eb_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: registration_registrationprofi_user_id_5fcbf725_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY registration_registrationprofile
    ADD CONSTRAINT registration_registrationprofi_user_id_5fcbf725_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

